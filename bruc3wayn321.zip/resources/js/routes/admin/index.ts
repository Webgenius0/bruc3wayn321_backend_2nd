import dashboard from './dashboard'
import user from './user'
import users from './users'
import posts from './posts'
import settings from './settings'
import profile from './profile'
import page from './page'
import faq from './faq'
import log from './log'
import queues from './queues'
import failedJobs from './failed-jobs'
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
user: Object.assign(user, user),
users: Object.assign(users, users),
posts: Object.assign(posts, posts),
settings: Object.assign(settings, settings),
profile: Object.assign(profile, profile),
page: Object.assign(page, page),
faq: Object.assign(faq, faq),
log: Object.assign(log, log),
queues: Object.assign(queues, queues),
failedJobs: Object.assign(failedJobs, failedJobs),
}

export default admin