import dashboard from './dashboard'
import notifications from './notifications'
import subscription from './subscription'
import user from './user'
import users from './users'
import posts from './posts'
import settings from './settings'
import profile from './profile'
import page from './page'
import faq from './faq'
import log from './log'
import queues from './queues'
import failedJobs from './failed-jobs'
import message from './message'
import supportIssues from './support-issues'
import report from './report'
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
notifications: Object.assign(notifications, notifications),
subscription: Object.assign(subscription, subscription),
user: Object.assign(user, user),
users: Object.assign(users, users),
posts: Object.assign(posts, posts),
settings: Object.assign(settings, settings),
profile: Object.assign(profile, profile),
page: Object.assign(page, page),
faq: Object.assign(faq, faq),
log: Object.assign(log, log),
queues: Object.assign(queues, queues),
failedJobs: Object.assign(failedJobs, failedJobs),
message: Object.assign(message, message),
supportIssues: Object.assign(supportIssues, supportIssues),
report: Object.assign(report, report),
}

export default admin