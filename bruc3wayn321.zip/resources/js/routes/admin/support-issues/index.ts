import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/support-issues',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::index
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:15
 * @route '/admin/support-issues'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
export const show = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/support-issues/{supportIssue}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
show.url = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supportIssue: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supportIssue: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supportIssue: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supportIssue: typeof args.supportIssue === 'object'
                ? args.supportIssue.id
                : args.supportIssue,
                }

    return show.definition.url
            .replace('{supportIssue}', parsedArgs.supportIssue.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
show.get = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
show.head = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
    const showForm = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
        showForm.get = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::show
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:29
 * @route '/admin/support-issues/{supportIssue}'
 */
        showForm.head = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::reply
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:36
 * @route '/admin/support-issues/{supportIssue}/reply'
 */
export const reply = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reply.url(args, options),
    method: 'put',
})

reply.definition = {
    methods: ["put"],
    url: '/admin/support-issues/{supportIssue}/reply',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::reply
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:36
 * @route '/admin/support-issues/{supportIssue}/reply'
 */
reply.url = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supportIssue: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supportIssue: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supportIssue: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supportIssue: typeof args.supportIssue === 'object'
                ? args.supportIssue.id
                : args.supportIssue,
                }

    return reply.definition.url
            .replace('{supportIssue}', parsedArgs.supportIssue.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::reply
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:36
 * @route '/admin/support-issues/{supportIssue}/reply'
 */
reply.put = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reply.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::reply
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:36
 * @route '/admin/support-issues/{supportIssue}/reply'
 */
    const replyForm = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reply.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SupportIssueController::reply
 * @see app/Http/Controllers/Web/Backend/SupportIssueController.php:36
 * @route '/admin/support-issues/{supportIssue}/reply'
 */
        replyForm.put = (args: { supportIssue: number | { id: number } } | [supportIssue: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reply.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reply.form = replyForm
const supportIssues = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
reply: Object.assign(reply, reply),
}

export default supportIssues