import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/faq/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::index
 * @see app/Http/Controllers/Web/Backend/FaqController.php:17
 * @route '/admin/faq/list'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/faq/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::create
 * @see app/Http/Controllers/Web/Backend/FaqController.php:30
 * @route '/admin/faq/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::store
 * @see app/Http/Controllers/Web/Backend/FaqController.php:42
 * @route '/admin/faq/store'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/faq/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::store
 * @see app/Http/Controllers/Web/Backend/FaqController.php:42
 * @route '/admin/faq/store'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::store
 * @see app/Http/Controllers/Web/Backend/FaqController.php:42
 * @route '/admin/faq/store'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::store
 * @see app/Http/Controllers/Web/Backend/FaqController.php:42
 * @route '/admin/faq/store'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::store
 * @see app/Http/Controllers/Web/Backend/FaqController.php:42
 * @route '/admin/faq/store'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
export const edit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/faq/edit/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
edit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return edit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
edit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
edit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
    const editForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
        editForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::edit
 * @see app/Http/Controllers/Web/Backend/FaqController.php:65
 * @route '/admin/faq/edit/{id}'
 */
        editForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::update
 * @see app/Http/Controllers/Web/Backend/FaqController.php:77
 * @route '/admin/faq/update/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/faq/update/{id}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::update
 * @see app/Http/Controllers/Web/Backend/FaqController.php:77
 * @route '/admin/faq/update/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::update
 * @see app/Http/Controllers/Web/Backend/FaqController.php:77
 * @route '/admin/faq/update/{id}'
 */
update.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::update
 * @see app/Http/Controllers/Web/Backend/FaqController.php:77
 * @route '/admin/faq/update/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::update
 * @see app/Http/Controllers/Web/Backend/FaqController.php:77
 * @route '/admin/faq/update/{id}'
 */
        updateForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Web\Backend\FaqController::deleteMethod
 * @see app/Http/Controllers/Web/Backend/FaqController.php:94
 * @route '/admin/faq/delete/{id}'
 */
export const deleteMethod = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

deleteMethod.definition = {
    methods: ["delete"],
    url: '/admin/faq/delete/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::deleteMethod
 * @see app/Http/Controllers/Web/Backend/FaqController.php:94
 * @route '/admin/faq/delete/{id}'
 */
deleteMethod.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return deleteMethod.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\FaqController::deleteMethod
 * @see app/Http/Controllers/Web/Backend/FaqController.php:94
 * @route '/admin/faq/delete/{id}'
 */
deleteMethod.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\Backend\FaqController::deleteMethod
 * @see app/Http/Controllers/Web/Backend/FaqController.php:94
 * @route '/admin/faq/delete/{id}'
 */
    const deleteMethodForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMethod.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\FaqController::deleteMethod
 * @see app/Http/Controllers/Web/Backend/FaqController.php:94
 * @route '/admin/faq/delete/{id}'
 */
        deleteMethodForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteMethod.form = deleteMethodForm
const faq = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
delete: Object.assign(deleteMethod, deleteMethod),
}

export default faq