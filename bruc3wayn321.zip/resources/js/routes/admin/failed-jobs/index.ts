import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/failed-jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:24
 * @route '/admin/failed-jobs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::retry
 * @see app/Http/Controllers/Web/Backend/QueueController.php:52
 * @route '/admin/failed-jobs/{id}/retry'
 */
export const retry = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

retry.definition = {
    methods: ["post"],
    url: '/admin/failed-jobs/{id}/retry',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::retry
 * @see app/Http/Controllers/Web/Backend/QueueController.php:52
 * @route '/admin/failed-jobs/{id}/retry'
 */
retry.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return retry.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::retry
 * @see app/Http/Controllers/Web/Backend/QueueController.php:52
 * @route '/admin/failed-jobs/{id}/retry'
 */
retry.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\QueueController::retry
 * @see app/Http/Controllers/Web/Backend/QueueController.php:52
 * @route '/admin/failed-jobs/{id}/retry'
 */
    const retryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retry.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::retry
 * @see app/Http/Controllers/Web/Backend/QueueController.php:52
 * @route '/admin/failed-jobs/{id}/retry'
 */
        retryForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retry.url(args, options),
            method: 'post',
        })
    
    retry.form = retryForm
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::destroy
 * @see app/Http/Controllers/Web/Backend/QueueController.php:43
 * @route '/admin/failed-jobs/{id}'
 */
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/failed-jobs/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::destroy
 * @see app/Http/Controllers/Web/Backend/QueueController.php:43
 * @route '/admin/failed-jobs/{id}'
 */
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::destroy
 * @see app/Http/Controllers/Web/Backend/QueueController.php:43
 * @route '/admin/failed-jobs/{id}'
 */
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\Backend\QueueController::destroy
 * @see app/Http/Controllers/Web/Backend/QueueController.php:43
 * @route '/admin/failed-jobs/{id}'
 */
    const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::destroy
 * @see app/Http/Controllers/Web/Backend/QueueController.php:43
 * @route '/admin/failed-jobs/{id}'
 */
        destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const failedJobs = {
    index: Object.assign(index, index),
retry: Object.assign(retry, retry),
destroy: Object.assign(destroy, destroy),
}

export default failedJobs