import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
export const index = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/page/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
index.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return index.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
index.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
index.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
    const indexForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
        indexForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::index
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
        indexForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::update
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
export const update = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/page/update/{slug}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::update
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
update.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return update.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::update
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
update.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::update
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
    const updateForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::update
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
        updateForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
const page = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
}

export default page