import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\LogController::index
 * @see app/Http/Controllers/Web/Backend/LogController.php:14
 * @route '/admin/logs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\LogController::clear
 * @see app/Http/Controllers/Web/Backend/LogController.php:46
 * @route '/admin/logs'
 */
export const clear = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

clear.definition = {
    methods: ["delete"],
    url: '/admin/logs',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\Backend\LogController::clear
 * @see app/Http/Controllers/Web/Backend/LogController.php:46
 * @route '/admin/logs'
 */
clear.url = (options?: RouteQueryOptions) => {
    return clear.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\LogController::clear
 * @see app/Http/Controllers/Web/Backend/LogController.php:46
 * @route '/admin/logs'
 */
clear.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\Backend\LogController::clear
 * @see app/Http/Controllers/Web/Backend/LogController.php:46
 * @route '/admin/logs'
 */
    const clearForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\LogController::clear
 * @see app/Http/Controllers/Web/Backend/LogController.php:46
 * @route '/admin/logs'
 */
        clearForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clear.form = clearForm
const log = {
    index: Object.assign(index, index),
clear: Object.assign(clear, clear),
}

export default log