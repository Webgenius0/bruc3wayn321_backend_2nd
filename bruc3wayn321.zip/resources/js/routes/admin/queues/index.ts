import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/queues',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\QueueController::index
 * @see app/Http/Controllers/Web/Backend/QueueController.php:13
 * @route '/admin/queues'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const queues = {
    index: Object.assign(index, index),
}

export default queues