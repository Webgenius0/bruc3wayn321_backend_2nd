import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/subscription-limits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
export const updateLimits = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLimits.url(options),
    method: 'post',
})

updateLimits.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/limits',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
updateLimits.url = (options?: RouteQueryOptions) => {
    return updateLimits.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
updateLimits.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLimits.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
    const updateLimitsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLimits.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
        updateLimitsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLimits.url(options),
            method: 'post',
        })
    
    updateLimits.form = updateLimitsForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::trialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
export const trialSettings = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: trialSettings.url(options),
    method: 'post',
})

trialSettings.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/trial-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::trialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
trialSettings.url = (options?: RouteQueryOptions) => {
    return trialSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::trialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
trialSettings.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: trialSettings.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::trialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
    const trialSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: trialSettings.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::trialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
        trialSettingsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: trialSettings.url(options),
            method: 'post',
        })
    
    trialSettings.form = trialSettingsForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/admin/subscription-limits/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::users
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
export const resetUsage = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetUsage.url(args, options),
    method: 'post',
})

resetUsage.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/reset-usage',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
resetUsage.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return resetUsage.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
resetUsage.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetUsage.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
    const resetUsageForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetUsage.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
        resetUsageForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetUsage.url(args, options),
            method: 'post',
        })
    
    resetUsage.form = resetUsageForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
export const forceUpgrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

forceUpgrade.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/force-upgrade',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
forceUpgrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceUpgrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
forceUpgrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
    const forceUpgradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceUpgrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
        forceUpgradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceUpgrade.url(args, options),
            method: 'post',
        })
    
    forceUpgrade.form = forceUpgradeForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
export const forceDowngrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

forceDowngrade.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/force-downgrade',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
forceDowngrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceDowngrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
forceDowngrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
    const forceDowngradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDowngrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
        forceDowngradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDowngrade.url(args, options),
            method: 'post',
        })
    
    forceDowngrade.form = forceDowngradeForm
const subscriptionLimits = {
    index: Object.assign(index, index),
updateLimits: Object.assign(updateLimits, updateLimits),
trialSettings: Object.assign(trialSettings, trialSettings),
users: Object.assign(users, users),
resetUsage: Object.assign(resetUsage, resetUsage),
forceUpgrade: Object.assign(forceUpgrade, forceUpgrade),
forceDowngrade: Object.assign(forceDowngrade, forceDowngrade),
}

export default subscriptionLimits