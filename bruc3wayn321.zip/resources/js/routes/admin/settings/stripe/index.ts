import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/settings/stripe/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const stripe = {
    update: Object.assign(update, update),
}

export default stripe