import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/settings/system',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/settings/system/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const system = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
}

export default system