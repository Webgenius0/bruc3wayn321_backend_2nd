import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/settings/smtp/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const smtp = {
    update: Object.assign(update, update),
}

export default smtp