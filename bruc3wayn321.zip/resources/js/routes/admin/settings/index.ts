import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import system from './system'
import smtp15ae78 from './smtp'
import stripe816ab9 from './stripe'
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
export const smtp = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: smtp.url(options),
    method: 'get',
})

smtp.definition = {
    methods: ["get","head"],
    url: '/admin/settings/smtp',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.url = (options?: RouteQueryOptions) => {
    return smtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: smtp.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: smtp.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
    const smtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: smtp.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
        smtpForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: smtp.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
        smtpForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: smtp.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    smtp.form = smtpForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
export const stripe = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stripe.url(options),
    method: 'get',
})

stripe.definition = {
    methods: ["get","head"],
    url: '/admin/settings/stripe',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.url = (options?: RouteQueryOptions) => {
    return stripe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stripe.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stripe.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
    const stripeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stripe.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
        stripeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stripe.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
        stripeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stripe.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stripe.form = stripeForm
const settings = {
    system: Object.assign(system, system),
smtp: Object.assign(smtp, smtp15ae78),
stripe: Object.assign(stripe, stripe816ab9),
}

export default settings