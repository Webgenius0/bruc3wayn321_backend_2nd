import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::index
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
export const details = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: details.url(args, options),
    method: 'get',
})

details.definition = {
    methods: ["get","head"],
    url: '/admin/reports/show/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
details.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return details.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
details.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: details.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
details.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: details.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
    const detailsForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: details.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
        detailsForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: details.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::details
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
        detailsForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: details.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    details.form = detailsForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
export const edit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/reports/edit/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
edit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return edit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
edit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
edit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
    const editForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
        editForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::edit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
        editForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/reports/update/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
export const toggleActiveStatus = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: toggleActiveStatus.url(args, options),
    method: 'put',
})

toggleActiveStatus.definition = {
    methods: ["put"],
    url: '/admin/reports/toggle-active-status/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
toggleActiveStatus.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return toggleActiveStatus.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
toggleActiveStatus.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: toggleActiveStatus.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
    const toggleActiveStatusForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleActiveStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
        toggleActiveStatusForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleActiveStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleActiveStatus.form = toggleActiveStatusForm
const report = {
    index: Object.assign(index, index),
details: Object.assign(details, details),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
toggleActiveStatus: Object.assign(toggleActiveStatus, toggleActiveStatus),
}

export default report