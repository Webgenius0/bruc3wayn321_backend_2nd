import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import privacy from './privacy'
import terms from './terms'
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
export const support = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: support.url(options),
    method: 'get',
})

support.definition = {
    methods: ["get","head"],
    url: '/support',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
support.url = (options?: RouteQueryOptions) => {
    return support.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
support.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: support.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
support.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: support.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
    const supportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: support.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
        supportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: support.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::support
 * @see app/Http/Controllers/Web/Frontend/PageController.php:27
 * @route '/support'
 */
        supportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: support.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    support.form = supportForm
const frontend = {
    privacy: Object.assign(privacy, privacy),
terms: Object.assign(terms, terms),
support: Object.assign(support, support),
}

export default frontend