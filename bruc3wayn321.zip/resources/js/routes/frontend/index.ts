import privacy from './privacy'
import terms from './terms'
const frontend = {
    privacy: Object.assign(privacy, privacy),
terms: Object.assign(terms, terms),
}

export default frontend