import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
export const conditions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conditions.url(options),
    method: 'get',
})

conditions.definition = {
    methods: ["get","head"],
    url: '/terms-and-conditions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
conditions.url = (options?: RouteQueryOptions) => {
    return conditions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
conditions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conditions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
conditions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conditions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
    const conditionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: conditions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
        conditionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conditions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::conditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
        conditionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conditions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    conditions.form = conditionsForm
const terms = {
    conditions: Object.assign(conditions, conditions),
}

export default terms