import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
export const enterName = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enterName.url(options),
    method: 'get',
})

enterName.definition = {
    methods: ["get","head"],
    url: '/chat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.url = (options?: RouteQueryOptions) => {
    return enterName.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enterName.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: enterName.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
    const enterNameForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: enterName.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
        enterNameForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enterName.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
        enterNameForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enterName.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    enterName.form = enterNameForm
/**
* @see \App\Http\Controllers\ChatAppController::room
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
export const room = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: room.url(options),
    method: 'post',
})

room.definition = {
    methods: ["post"],
    url: '/chat/room',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChatAppController::room
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
room.url = (options?: RouteQueryOptions) => {
    return room.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::room
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
room.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: room.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChatAppController::room
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
    const roomForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: room.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::room
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
        roomForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: room.url(options),
            method: 'post',
        })
    
    room.form = roomForm
/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
export const sendMessage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

sendMessage.definition = {
    methods: ["post"],
    url: '/send-message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
sendMessage.url = (options?: RouteQueryOptions) => {
    return sendMessage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
sendMessage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
    const sendMessageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendMessage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
        sendMessageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendMessage.url(options),
            method: 'post',
        })
    
    sendMessage.form = sendMessageForm
const chat = {
    enterName: Object.assign(enterName, enterName),
room: Object.assign(room, room),
sendMessage: Object.assign(sendMessage, sendMessage),
}

export default chat