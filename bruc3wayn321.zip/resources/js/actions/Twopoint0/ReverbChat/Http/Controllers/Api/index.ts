import ChatApiController from './ChatApiController'
const Api = {
    ChatApiController: Object.assign(ChatApiController, ChatApiController),
}

export default Api