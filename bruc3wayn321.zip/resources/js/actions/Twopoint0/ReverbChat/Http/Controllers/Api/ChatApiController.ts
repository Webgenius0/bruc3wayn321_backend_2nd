import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::openOrCreate
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:18
 * @route '/api/chat/open-group'
 */
export const openOrCreate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: openOrCreate.url(options),
    method: 'post',
})

openOrCreate.definition = {
    methods: ["post"],
    url: '/api/chat/open-group',
} satisfies RouteDefinition<["post"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::openOrCreate
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:18
 * @route '/api/chat/open-group'
 */
openOrCreate.url = (options?: RouteQueryOptions) => {
    return openOrCreate.definition.url + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::openOrCreate
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:18
 * @route '/api/chat/open-group'
 */
openOrCreate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: openOrCreate.url(options),
    method: 'post',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::openOrCreate
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:18
 * @route '/api/chat/open-group'
 */
    const openOrCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: openOrCreate.url(options),
        method: 'post',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::openOrCreate
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:18
 * @route '/api/chat/open-group'
 */
        openOrCreateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: openOrCreate.url(options),
            method: 'post',
        })
    
    openOrCreate.form = openOrCreateForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByChat
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:81
 * @route '/api/chat/{chat}/message'
 */
export const sendByChat = (args: { chat: number | { id: number } } | [chat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendByChat.url(args, options),
    method: 'post',
})

sendByChat.definition = {
    methods: ["post"],
    url: '/api/chat/{chat}/message',
} satisfies RouteDefinition<["post"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByChat
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:81
 * @route '/api/chat/{chat}/message'
 */
sendByChat.url = (args: { chat: number | { id: number } } | [chat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { chat: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { chat: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    chat: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        chat: typeof args.chat === 'object'
                ? args.chat.id
                : args.chat,
                }

    return sendByChat.definition.url
            .replace('{chat}', parsedArgs.chat.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByChat
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:81
 * @route '/api/chat/{chat}/message'
 */
sendByChat.post = (args: { chat: number | { id: number } } | [chat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendByChat.url(args, options),
    method: 'post',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByChat
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:81
 * @route '/api/chat/{chat}/message'
 */
    const sendByChatForm = (args: { chat: number | { id: number } } | [chat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendByChat.url(args, options),
        method: 'post',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByChat
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:81
 * @route '/api/chat/{chat}/message'
 */
        sendByChatForm.post = (args: { chat: number | { id: number } } | [chat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendByChat.url(args, options),
            method: 'post',
        })
    
    sendByChat.form = sendByChatForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByUser
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:94
 * @route '/api/chat/user/{user}/message'
 */
export const sendByUser = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendByUser.url(args, options),
    method: 'post',
})

sendByUser.definition = {
    methods: ["post"],
    url: '/api/chat/user/{user}/message',
} satisfies RouteDefinition<["post"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByUser
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:94
 * @route '/api/chat/user/{user}/message'
 */
sendByUser.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return sendByUser.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByUser
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:94
 * @route '/api/chat/user/{user}/message'
 */
sendByUser.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendByUser.url(args, options),
    method: 'post',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByUser
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:94
 * @route '/api/chat/user/{user}/message'
 */
    const sendByUserForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendByUser.url(args, options),
        method: 'post',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::sendByUser
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:94
 * @route '/api/chat/user/{user}/message'
 */
        sendByUserForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendByUser.url(args, options),
            method: 'post',
        })
    
    sendByUser.form = sendByUserForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
export const messagelist = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: messagelist.url(args, options),
    method: 'get',
})

messagelist.definition = {
    methods: ["get","head"],
    url: '/api/chat/messages/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
messagelist.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return messagelist.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
messagelist.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: messagelist.url(args, options),
    method: 'get',
})
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
messagelist.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: messagelist.url(args, options),
    method: 'head',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
    const messagelistForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: messagelist.url(args, options),
        method: 'get',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
        messagelistForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: messagelist.url(args, options),
            method: 'get',
        })
            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::messagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:230
 * @route '/api/chat/messages/{id}'
 */
        messagelistForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: messagelist.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    messagelist.form = messagelistForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
export const usermessagelist = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usermessagelist.url(args, options),
    method: 'get',
})

usermessagelist.definition = {
    methods: ["get","head"],
    url: '/api/chat/messages/user/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
usermessagelist.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return usermessagelist.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
usermessagelist.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usermessagelist.url(args, options),
    method: 'get',
})
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
usermessagelist.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usermessagelist.url(args, options),
    method: 'head',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
    const usermessagelistForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: usermessagelist.url(args, options),
        method: 'get',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
        usermessagelistForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usermessagelist.url(args, options),
            method: 'get',
        })
            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::usermessagelist
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:334
 * @route '/api/chat/messages/user/{id}'
 */
        usermessagelistForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usermessagelist.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    usermessagelist.form = usermessagelistForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
export const chatList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chatList.url(options),
    method: 'get',
})

chatList.definition = {
    methods: ["get","head"],
    url: '/api/chat/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
chatList.url = (options?: RouteQueryOptions) => {
    return chatList.definition.url + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
chatList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chatList.url(options),
    method: 'get',
})
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
chatList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: chatList.url(options),
    method: 'head',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
    const chatListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: chatList.url(options),
        method: 'get',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
        chatListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chatList.url(options),
            method: 'get',
        })
            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Api\ChatApiController::chatList
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Api/ChatApiController.php:258
 * @route '/api/chat/list'
 */
        chatListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chatList.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    chatList.form = chatListForm
const ChatApiController = { openOrCreate, sendByChat, sendByUser, messagelist, usermessagelist, chatList }

export default ChatApiController