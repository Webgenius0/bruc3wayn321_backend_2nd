import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
export const message = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: message.url(options),
    method: 'get',
})

message.definition = {
    methods: ["get","head"],
    url: '/message',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
message.url = (options?: RouteQueryOptions) => {
    return message.definition.url + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
message.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: message.url(options),
    method: 'get',
})
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
message.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: message.url(options),
    method: 'head',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
    const messageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: message.url(options),
        method: 'get',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
        messageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: message.url(options),
            method: 'get',
        })
            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::message
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:11
 * @route '/message'
 */
        messageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: message.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    message.form = messageForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::chatroom
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:15
 * @route '/chatroom'
 */
export const chatroom = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chatroom.url(options),
    method: 'post',
})

chatroom.definition = {
    methods: ["post"],
    url: '/chatroom',
} satisfies RouteDefinition<["post"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::chatroom
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:15
 * @route '/chatroom'
 */
chatroom.url = (options?: RouteQueryOptions) => {
    return chatroom.definition.url + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::chatroom
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:15
 * @route '/chatroom'
 */
chatroom.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chatroom.url(options),
    method: 'post',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::chatroom
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:15
 * @route '/chatroom'
 */
    const chatroomForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: chatroom.url(options),
        method: 'post',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::chatroom
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:15
 * @route '/chatroom'
 */
        chatroomForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: chatroom.url(options),
            method: 'post',
        })
    
    chatroom.form = chatroomForm
/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::sendMessage
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:23
 * @route '/send-message'
 */
export const sendMessage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

sendMessage.definition = {
    methods: ["post"],
    url: '/send-message',
} satisfies RouteDefinition<["post"]>

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::sendMessage
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:23
 * @route '/send-message'
 */
sendMessage.url = (options?: RouteQueryOptions) => {
    return sendMessage.definition.url + queryParams(options)
}

/**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::sendMessage
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:23
 * @route '/send-message'
 */
sendMessage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

    /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::sendMessage
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:23
 * @route '/send-message'
 */
    const sendMessageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendMessage.url(options),
        method: 'post',
    })

            /**
* @see \Twopoint0\ReverbChat\Http\Controllers\Web\ChatAppController::sendMessage
 * @see vendor/twopoint0/reverb-chat/src/Http/Controllers/Web/ChatAppController.php:23
 * @route '/send-message'
 */
        sendMessageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendMessage.url(options),
            method: 'post',
        })
    
    sendMessage.form = sendMessageForm
const ChatAppController = { message, chatroom, sendMessage }

export default ChatAppController