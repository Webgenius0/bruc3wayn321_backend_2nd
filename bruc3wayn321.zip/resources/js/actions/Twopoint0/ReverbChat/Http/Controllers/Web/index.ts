import ChatAppController from './ChatAppController'
const Web = {
    ChatAppController: Object.assign(ChatAppController, ChatAppController),
}

export default Web