import Http from './Http'
const ReverbChat = {
    Http: Object.assign(Http, Http),
}

export default ReverbChat