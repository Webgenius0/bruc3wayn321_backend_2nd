import ReverbChat from './ReverbChat'
const Twopoint0 = {
    ReverbChat: Object.assign(ReverbChat, ReverbChat),
}

export default Twopoint0