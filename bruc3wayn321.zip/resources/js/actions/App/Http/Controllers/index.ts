import API from './API'
import Web from './Web'
import Settings from './Settings'
const Controllers = {
    API: Object.assign(API, API),
Web: Object.assign(Web, Web),
Settings: Object.assign(Settings, Settings),
}

export default Controllers