import API from './API'
import Web from './Web'
import Settings from './Settings'
import ChatAppController from './ChatAppController'
const Controllers = {
    API: Object.assign(API, API),
Web: Object.assign(Web, Web),
Settings: Object.assign(Settings, Settings),
ChatAppController: Object.assign(ChatAppController, ChatAppController),
}

export default Controllers