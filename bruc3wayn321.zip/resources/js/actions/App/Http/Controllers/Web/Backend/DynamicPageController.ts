import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
export const dynamicPage = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dynamicPage.url(args, options),
    method: 'get',
})

dynamicPage.definition = {
    methods: ["get","head"],
    url: '/admin/page/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
dynamicPage.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return dynamicPage.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
dynamicPage.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dynamicPage.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
dynamicPage.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dynamicPage.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
    const dynamicPageForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dynamicPage.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
        dynamicPageForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dynamicPage.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::dynamicPage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:15
 * @route '/admin/page/{slug}'
 */
        dynamicPageForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dynamicPage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dynamicPage.form = dynamicPageForm
/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::updatePage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
export const updatePage = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePage.url(args, options),
    method: 'post',
})

updatePage.definition = {
    methods: ["post"],
    url: '/admin/page/update/{slug}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::updatePage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
updatePage.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return updatePage.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::updatePage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
updatePage.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePage.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::updatePage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
    const updatePageForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePage.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\DynamicPageController::updatePage
 * @see app/Http/Controllers/Web/Backend/DynamicPageController.php:31
 * @route '/admin/page/update/{slug}'
 */
        updatePageForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePage.url(args, options),
            method: 'post',
        })
    
    updatePage.form = updatePageForm
const DynamicPageController = { dynamicPage, updatePage }

export default DynamicPageController