import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
export const Reportindex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Reportindex.url(options),
    method: 'get',
})

Reportindex.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
Reportindex.url = (options?: RouteQueryOptions) => {
    return Reportindex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
Reportindex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Reportindex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
Reportindex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Reportindex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
    const ReportindexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Reportindex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
        ReportindexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Reportindex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::Reportindex
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:12
 * @route '/admin/reports'
 */
        ReportindexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Reportindex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Reportindex.form = ReportindexForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
export const reportDetails = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportDetails.url(args, options),
    method: 'get',
})

reportDetails.definition = {
    methods: ["get","head"],
    url: '/admin/reports/show/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
reportDetails.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return reportDetails.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
reportDetails.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportDetails.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
reportDetails.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reportDetails.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
    const reportDetailsForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reportDetails.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
        reportDetailsForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportDetails.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportDetails
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:24
 * @route '/admin/reports/show/{id}'
 */
        reportDetailsForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportDetails.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reportDetails.form = reportDetailsForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
export const reportEdit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportEdit.url(args, options),
    method: 'get',
})

reportEdit.definition = {
    methods: ["get","head"],
    url: '/admin/reports/edit/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
reportEdit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return reportEdit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
reportEdit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportEdit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
reportEdit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reportEdit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
    const reportEditForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reportEdit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
        reportEditForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportEdit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::reportEdit
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:36
 * @route '/admin/reports/edit/{id}'
 */
        reportEditForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportEdit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reportEdit.form = reportEditForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/reports/update/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::update
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:49
 * @route '/admin/reports/update/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
export const toggleActiveStatus = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: toggleActiveStatus.url(args, options),
    method: 'put',
})

toggleActiveStatus.definition = {
    methods: ["put"],
    url: '/admin/reports/toggle-active-status/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
toggleActiveStatus.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return toggleActiveStatus.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
toggleActiveStatus.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: toggleActiveStatus.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
    const toggleActiveStatusForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleActiveStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\UserBlockReportAdminController::toggleActiveStatus
 * @see app/Http/Controllers/Web/Backend/UserBlockReportAdminController.php:66
 * @route '/admin/reports/toggle-active-status/{id}'
 */
        toggleActiveStatusForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleActiveStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleActiveStatus.form = toggleActiveStatusForm
const UserBlockReportAdminController = { Reportindex, reportDetails, reportEdit, update, toggleActiveStatus }

export default UserBlockReportAdminController