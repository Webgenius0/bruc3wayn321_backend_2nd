import DashboardController from './DashboardController'
import NotificationController from './NotificationController'
import SubscriptionPlanController from './SubscriptionPlanController'
import SubscriptionLimitController from './SubscriptionLimitController'
import UserController from './UserController'
import Post from './Post'
import SystemSettingsController from './SystemSettingsController'
import ProfileController from './ProfileController'
import DynamicPageController from './DynamicPageController'
import FaqController from './FaqController'
import LogController from './LogController'
import QueueController from './QueueController'
import MessageController from './MessageController'
import SupportIssueController from './SupportIssueController'
import UserBlockReportAdminController from './UserBlockReportAdminController'
const Backend = {
    DashboardController: Object.assign(DashboardController, DashboardController),
NotificationController: Object.assign(NotificationController, NotificationController),
SubscriptionPlanController: Object.assign(SubscriptionPlanController, SubscriptionPlanController),
SubscriptionLimitController: Object.assign(SubscriptionLimitController, SubscriptionLimitController),
UserController: Object.assign(UserController, UserController),
Post: Object.assign(Post, Post),
SystemSettingsController: Object.assign(SystemSettingsController, SystemSettingsController),
ProfileController: Object.assign(ProfileController, ProfileController),
DynamicPageController: Object.assign(DynamicPageController, DynamicPageController),
FaqController: Object.assign(FaqController, FaqController),
LogController: Object.assign(LogController, LogController),
QueueController: Object.assign(QueueController, QueueController),
MessageController: Object.assign(MessageController, MessageController),
SupportIssueController: Object.assign(SupportIssueController, SupportIssueController),
UserBlockReportAdminController: Object.assign(UserBlockReportAdminController, UserBlockReportAdminController),
}

export default Backend