import DashboardController from './DashboardController'
import UserController from './UserController'
import Post from './Post'
import SystemSettingsController from './SystemSettingsController'
import ProfileController from './ProfileController'
import DynamicPageController from './DynamicPageController'
import FaqController from './FaqController'
import LogController from './LogController'
import QueueController from './QueueController'
const Backend = {
    DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
Post: Object.assign(Post, Post),
SystemSettingsController: Object.assign(SystemSettingsController, SystemSettingsController),
ProfileController: Object.assign(ProfileController, ProfileController),
DynamicPageController: Object.assign(DynamicPageController, DynamicPageController),
FaqController: Object.assign(FaqController, FaqController),
LogController: Object.assign(LogController, LogController),
QueueController: Object.assign(QueueController, QueueController),
}

export default Backend