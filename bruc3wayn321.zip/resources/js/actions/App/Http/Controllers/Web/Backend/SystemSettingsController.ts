import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/settings/system',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::index
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:23
 * @route '/admin/settings/system'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/settings/system/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::update
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:42
 * @route '/admin/settings/system/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
export const smtp = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: smtp.url(options),
    method: 'get',
})

smtp.definition = {
    methods: ["get","head"],
    url: '/admin/settings/smtp',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.url = (options?: RouteQueryOptions) => {
    return smtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: smtp.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
smtp.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: smtp.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
    const smtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: smtp.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
        smtpForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: smtp.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::smtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:53
 * @route '/admin/settings/smtp'
 */
        smtpForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: smtp.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    smtp.form = smtpForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateSmtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
export const updateSmtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSmtp.url(options),
    method: 'post',
})

updateSmtp.definition = {
    methods: ["post"],
    url: '/admin/settings/smtp/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateSmtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
updateSmtp.url = (options?: RouteQueryOptions) => {
    return updateSmtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateSmtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
updateSmtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSmtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateSmtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
    const updateSmtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSmtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateSmtp
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:79
 * @route '/admin/settings/smtp/update'
 */
        updateSmtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSmtp.url(options),
            method: 'post',
        })
    
    updateSmtp.form = updateSmtpForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
export const stripe = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stripe.url(options),
    method: 'get',
})

stripe.definition = {
    methods: ["get","head"],
    url: '/admin/settings/stripe',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.url = (options?: RouteQueryOptions) => {
    return stripe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stripe.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
stripe.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stripe.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
    const stripeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stripe.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
        stripeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stripe.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::stripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:94
 * @route '/admin/settings/stripe'
 */
        stripeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stripe.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stripe.form = stripeForm
/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateStripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
export const updateStripe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStripe.url(options),
    method: 'post',
})

updateStripe.definition = {
    methods: ["post"],
    url: '/admin/settings/stripe/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateStripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
updateStripe.url = (options?: RouteQueryOptions) => {
    return updateStripe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateStripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
updateStripe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStripe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateStripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
    const updateStripeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStripe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SystemSettingsController::updateStripe
 * @see app/Http/Controllers/Web/Backend/SystemSettingsController.php:114
 * @route '/admin/settings/stripe/update'
 */
        updateStripeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStripe.url(options),
            method: 'post',
        })
    
    updateStripe.form = updateStripeForm
const SystemSettingsController = { index, update, smtp, updateSmtp, stripe, updateStripe }

export default SystemSettingsController