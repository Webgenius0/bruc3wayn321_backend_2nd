import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/subscription-limits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::index
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:19
 * @route '/admin/subscription-limits'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
export const updateLimits = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLimits.url(options),
    method: 'post',
})

updateLimits.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/limits',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
updateLimits.url = (options?: RouteQueryOptions) => {
    return updateLimits.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
updateLimits.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateLimits.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
    const updateLimitsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLimits.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateLimits
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:152
 * @route '/admin/subscription-limits/limits'
 */
        updateLimitsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLimits.url(options),
            method: 'post',
        })
    
    updateLimits.form = updateLimitsForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateTrialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
export const updateTrialSettings = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateTrialSettings.url(options),
    method: 'post',
})

updateTrialSettings.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/trial-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateTrialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
updateTrialSettings.url = (options?: RouteQueryOptions) => {
    return updateTrialSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateTrialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
updateTrialSettings.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateTrialSettings.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateTrialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
    const updateTrialSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTrialSettings.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::updateTrialSettings
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:0
 * @route '/admin/subscription-limits/trial-settings'
 */
        updateTrialSettingsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTrialSettings.url(options),
            method: 'post',
        })
    
    updateTrialSettings.form = updateTrialSettingsForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
export const userUsage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userUsage.url(options),
    method: 'get',
})

userUsage.definition = {
    methods: ["get","head"],
    url: '/admin/subscription-limits/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
userUsage.url = (options?: RouteQueryOptions) => {
    return userUsage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
userUsage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userUsage.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
userUsage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userUsage.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
    const userUsageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userUsage.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
        userUsageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userUsage.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::userUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:188
 * @route '/admin/subscription-limits/users'
 */
        userUsageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userUsage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userUsage.form = userUsageForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
export const resetUsage = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetUsage.url(args, options),
    method: 'post',
})

resetUsage.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/reset-usage',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
resetUsage.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return resetUsage.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
resetUsage.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetUsage.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
    const resetUsageForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetUsage.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::resetUsage
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:196
 * @route '/admin/subscription-limits/{userId}/reset-usage'
 */
        resetUsageForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetUsage.url(args, options),
            method: 'post',
        })
    
    resetUsage.form = resetUsageForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
export const forceUpgrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

forceUpgrade.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/force-upgrade',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
forceUpgrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceUpgrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
forceUpgrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
    const forceUpgradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceUpgrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceUpgrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:211
 * @route '/admin/subscription-limits/{userId}/force-upgrade'
 */
        forceUpgradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceUpgrade.url(args, options),
            method: 'post',
        })
    
    forceUpgrade.form = forceUpgradeForm
/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
export const forceDowngrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

forceDowngrade.definition = {
    methods: ["post"],
    url: '/admin/subscription-limits/{userId}/force-downgrade',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
forceDowngrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceDowngrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
forceDowngrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
    const forceDowngradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDowngrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Backend\SubscriptionLimitController::forceDowngrade
 * @see app/Http/Controllers/Web/Backend/SubscriptionLimitController.php:236
 * @route '/admin/subscription-limits/{userId}/force-downgrade'
 */
        forceDowngradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDowngrade.url(args, options),
            method: 'post',
        })
    
    forceDowngrade.form = forceDowngradeForm
const SubscriptionLimitController = { index, updateLimits, updateTrialSettings, userUsage, resetUsage, forceUpgrade, forceDowngrade }

export default SubscriptionLimitController