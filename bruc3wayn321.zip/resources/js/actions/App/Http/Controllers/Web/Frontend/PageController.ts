import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
export const privacyPolicy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacyPolicy.url(options),
    method: 'get',
})

privacyPolicy.definition = {
    methods: ["get","head"],
    url: '/privacy-policy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
privacyPolicy.url = (options?: RouteQueryOptions) => {
    return privacyPolicy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
privacyPolicy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacyPolicy.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
privacyPolicy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: privacyPolicy.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
    const privacyPolicyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: privacyPolicy.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
        privacyPolicyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: privacyPolicy.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::privacyPolicy
 * @see app/Http/Controllers/Web/Frontend/PageController.php:12
 * @route '/privacy-policy'
 */
        privacyPolicyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: privacyPolicy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    privacyPolicy.form = privacyPolicyForm
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
export const termsAndConditions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: termsAndConditions.url(options),
    method: 'get',
})

termsAndConditions.definition = {
    methods: ["get","head"],
    url: '/terms-and-conditions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
termsAndConditions.url = (options?: RouteQueryOptions) => {
    return termsAndConditions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
termsAndConditions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: termsAndConditions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
termsAndConditions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: termsAndConditions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
    const termsAndConditionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: termsAndConditions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
        termsAndConditionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: termsAndConditions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Frontend\PageController::termsAndConditions
 * @see app/Http/Controllers/Web/Frontend/PageController.php:22
 * @route '/terms-and-conditions'
 */
        termsAndConditionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: termsAndConditions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    termsAndConditions.form = termsAndConditionsForm
const PageController = { privacyPolicy, termsAndConditions }

export default PageController