import Backend from './Backend'
import Frontend from './Frontend'
const Web = {
    Backend: Object.assign(Backend, Backend),
Frontend: Object.assign(Frontend, Frontend),
}

export default Web