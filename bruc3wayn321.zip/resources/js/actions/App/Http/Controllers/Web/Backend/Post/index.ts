import PostController from './PostController'
const Post = {
    PostController: Object.assign(PostController, PostController),
}

export default Post