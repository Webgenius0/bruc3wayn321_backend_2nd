import PageController from './PageController'
const Frontend = {
    PageController: Object.assign(PageController, PageController),
}

export default Frontend