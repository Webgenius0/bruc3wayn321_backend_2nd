import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
export const enterName = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enterName.url(options),
    method: 'get',
})

enterName.definition = {
    methods: ["get","head"],
    url: '/chat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.url = (options?: RouteQueryOptions) => {
    return enterName.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: enterName.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
enterName.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: enterName.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
    const enterNameForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: enterName.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
        enterNameForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enterName.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ChatAppController::enterName
 * @see app/Http/Controllers/ChatAppController.php:12
 * @route '/chat'
 */
        enterNameForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: enterName.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    enterName.form = enterNameForm
/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
const chatroom5fee09a014e04fab0acaeac61e3f5bdc = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
    method: 'post',
})

chatroom5fee09a014e04fab0acaeac61e3f5bdc.definition = {
    methods: ["post"],
    url: '/chat/room',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
chatroom5fee09a014e04fab0acaeac61e3f5bdc.url = (options?: RouteQueryOptions) => {
    return chatroom5fee09a014e04fab0acaeac61e3f5bdc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
chatroom5fee09a014e04fab0acaeac61e3f5bdc.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
    const chatroom5fee09a014e04fab0acaeac61e3f5bdcForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
        chatroom5fee09a014e04fab0acaeac61e3f5bdcForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
            method: 'post',
        })
    
    chatroom5fee09a014e04fab0acaeac61e3f5bdc.form = chatroom5fee09a014e04fab0acaeac61e3f5bdcForm
    /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
const chatroom5fee09a014e04fab0acaeac61e3f5bdc = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
    method: 'get',
})

chatroom5fee09a014e04fab0acaeac61e3f5bdc.definition = {
    methods: ["get","head"],
    url: '/chat/room',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
chatroom5fee09a014e04fab0acaeac61e3f5bdc.url = (options?: RouteQueryOptions) => {
    return chatroom5fee09a014e04fab0acaeac61e3f5bdc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
chatroom5fee09a014e04fab0acaeac61e3f5bdc.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
chatroom5fee09a014e04fab0acaeac61e3f5bdc.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
    const chatroom5fee09a014e04fab0acaeac61e3f5bdcForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
        chatroom5fee09a014e04fab0acaeac61e3f5bdcForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ChatAppController::chatroom
 * @see app/Http/Controllers/ChatAppController.php:18
 * @route '/chat/room'
 */
        chatroom5fee09a014e04fab0acaeac61e3f5bdcForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chatroom5fee09a014e04fab0acaeac61e3f5bdc.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    chatroom5fee09a014e04fab0acaeac61e3f5bdc.form = chatroom5fee09a014e04fab0acaeac61e3f5bdcForm

/**
* Multiple routes resolve to \App\Http\Controllers\ChatAppController::chatroom, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `chatroom['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const chatroom = {
    '/chat/room': chatroom5fee09a014e04fab0acaeac61e3f5bdc,
    '/chat/room': chatroom5fee09a014e04fab0acaeac61e3f5bdc,
}

/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
export const sendMessage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

sendMessage.definition = {
    methods: ["post"],
    url: '/send-message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
sendMessage.url = (options?: RouteQueryOptions) => {
    return sendMessage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
sendMessage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendMessage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
    const sendMessageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendMessage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChatAppController::sendMessage
 * @see app/Http/Controllers/ChatAppController.php:35
 * @route '/send-message'
 */
        sendMessageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendMessage.url(options),
            method: 'post',
        })
    
    sendMessage.form = sendMessageForm
const ChatAppController = { enterName, chatroom, sendMessage }

export default ChatAppController