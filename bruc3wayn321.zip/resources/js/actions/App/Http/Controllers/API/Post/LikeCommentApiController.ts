import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::toggleLike
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:70
 * @route '/api/v1/posts/{post}/like'
 */
export const toggleLike = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleLike.url(args, options),
    method: 'post',
})

toggleLike.definition = {
    methods: ["post"],
    url: '/api/v1/posts/{post}/like',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::toggleLike
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:70
 * @route '/api/v1/posts/{post}/like'
 */
toggleLike.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return toggleLike.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::toggleLike
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:70
 * @route '/api/v1/posts/{post}/like'
 */
toggleLike.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleLike.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::toggleLike
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:70
 * @route '/api/v1/posts/{post}/like'
 */
    const toggleLikeForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleLike.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::toggleLike
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:70
 * @route '/api/v1/posts/{post}/like'
 */
        toggleLikeForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleLike.url(args, options),
            method: 'post',
        })
    
    toggleLike.form = toggleLikeForm
/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::comment
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:33
 * @route '/api/v1/posts/{post}/comment'
 */
export const comment = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: comment.url(args, options),
    method: 'post',
})

comment.definition = {
    methods: ["post"],
    url: '/api/v1/posts/{post}/comment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::comment
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:33
 * @route '/api/v1/posts/{post}/comment'
 */
comment.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return comment.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::comment
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:33
 * @route '/api/v1/posts/{post}/comment'
 */
comment.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: comment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::comment
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:33
 * @route '/api/v1/posts/{post}/comment'
 */
    const commentForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: comment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::comment
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:33
 * @route '/api/v1/posts/{post}/comment'
 */
        commentForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: comment.url(args, options),
            method: 'post',
        })
    
    comment.form = commentForm
/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
export const commentList = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commentList.url(args, options),
    method: 'get',
})

commentList.definition = {
    methods: ["get","head"],
    url: '/api/v1/posts/{post}/comments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
commentList.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return commentList.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
commentList.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commentList.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
commentList.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: commentList.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
    const commentListForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: commentList.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
        commentListForm.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commentList.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::commentList
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:82
 * @route '/api/v1/posts/{post}/comments'
 */
        commentListForm.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: commentList.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    commentList.form = commentListForm
/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::view
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:95
 * @route '/api/v1/posts/{post}/view'
 */
export const view = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: view.url(args, options),
    method: 'post',
})

view.definition = {
    methods: ["post"],
    url: '/api/v1/posts/{post}/view',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::view
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:95
 * @route '/api/v1/posts/{post}/view'
 */
view.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return view.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::view
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:95
 * @route '/api/v1/posts/{post}/view'
 */
view.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: view.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::view
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:95
 * @route '/api/v1/posts/{post}/view'
 */
    const viewForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: view.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\LikeCommentApiController::view
 * @see app/Http/Controllers/API/Post/LikeCommentApiController.php:95
 * @route '/api/v1/posts/{post}/view'
 */
        viewForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: view.url(args, options),
            method: 'post',
        })
    
    view.form = viewForm
const LikeCommentApiController = { toggleLike, comment, commentList, view }

export default LikeCommentApiController