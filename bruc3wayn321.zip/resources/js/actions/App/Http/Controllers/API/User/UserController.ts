import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/api/v1/user/details',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
    const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
        profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\User\UserController::profile
 * @see app/Http/Controllers/API/User/UserController.php:36
 * @route '/api/v1/user/details'
 */
        profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profile.form = profileForm
/**
* @see \App\Http\Controllers\API\User\UserController::update
 * @see app/Http/Controllers/API/User/UserController.php:42
 * @route '/api/v1/user/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/api/v1/user/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::update
 * @see app/Http/Controllers/API/User/UserController.php:42
 * @route '/api/v1/user/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::update
 * @see app/Http/Controllers/API/User/UserController.php:42
 * @route '/api/v1/user/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::update
 * @see app/Http/Controllers/API/User/UserController.php:42
 * @route '/api/v1/user/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::update
 * @see app/Http/Controllers/API/User/UserController.php:42
 * @route '/api/v1/user/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\API\User\UserController::updatePassword
 * @see app/Http/Controllers/API/User/UserController.php:50
 * @route '/api/v1/user/update-password'
 */
export const updatePassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePassword.url(options),
    method: 'post',
})

updatePassword.definition = {
    methods: ["post"],
    url: '/api/v1/user/update-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::updatePassword
 * @see app/Http/Controllers/API/User/UserController.php:50
 * @route '/api/v1/user/update-password'
 */
updatePassword.url = (options?: RouteQueryOptions) => {
    return updatePassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::updatePassword
 * @see app/Http/Controllers/API/User/UserController.php:50
 * @route '/api/v1/user/update-password'
 */
updatePassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePassword.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::updatePassword
 * @see app/Http/Controllers/API/User/UserController.php:50
 * @route '/api/v1/user/update-password'
 */
    const updatePasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePassword.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::updatePassword
 * @see app/Http/Controllers/API/User/UserController.php:50
 * @route '/api/v1/user/update-password'
 */
        updatePasswordForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePassword.url(options),
            method: 'post',
        })
    
    updatePassword.form = updatePasswordForm
/**
* @see \App\Http\Controllers\API\User\UserController::updateNotifications
 * @see app/Http/Controllers/API/User/UserController.php:75
 * @route '/api/v1/user/notifications'
 */
export const updateNotifications = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateNotifications.url(options),
    method: 'post',
})

updateNotifications.definition = {
    methods: ["post"],
    url: '/api/v1/user/notifications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::updateNotifications
 * @see app/Http/Controllers/API/User/UserController.php:75
 * @route '/api/v1/user/notifications'
 */
updateNotifications.url = (options?: RouteQueryOptions) => {
    return updateNotifications.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::updateNotifications
 * @see app/Http/Controllers/API/User/UserController.php:75
 * @route '/api/v1/user/notifications'
 */
updateNotifications.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateNotifications.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::updateNotifications
 * @see app/Http/Controllers/API/User/UserController.php:75
 * @route '/api/v1/user/notifications'
 */
    const updateNotificationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateNotifications.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::updateNotifications
 * @see app/Http/Controllers/API/User/UserController.php:75
 * @route '/api/v1/user/notifications'
 */
        updateNotificationsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateNotifications.url(options),
            method: 'post',
        })
    
    updateNotifications.form = updateNotificationsForm
/**
* @see \App\Http\Controllers\API\User\UserController::destroy
 * @see app/Http/Controllers/API/User/UserController.php:111
 * @route '/api/v1/user/delete'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/user/delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\API\User\UserController::destroy
 * @see app/Http/Controllers/API/User/UserController.php:111
 * @route '/api/v1/user/delete'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::destroy
 * @see app/Http/Controllers/API/User/UserController.php:111
 * @route '/api/v1/user/delete'
 */
destroy.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::destroy
 * @see app/Http/Controllers/API/User/UserController.php:111
 * @route '/api/v1/user/delete'
 */
    const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::destroy
 * @see app/Http/Controllers/API/User/UserController.php:111
 * @route '/api/v1/user/delete'
 */
        destroyForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\API\User\UserController::updateCoverImage
 * @see app/Http/Controllers/API/User/UserController.php:245
 * @route '/api/v1/user/update/cover-image'
 */
export const updateCoverImage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateCoverImage.url(options),
    method: 'post',
})

updateCoverImage.definition = {
    methods: ["post"],
    url: '/api/v1/user/update/cover-image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::updateCoverImage
 * @see app/Http/Controllers/API/User/UserController.php:245
 * @route '/api/v1/user/update/cover-image'
 */
updateCoverImage.url = (options?: RouteQueryOptions) => {
    return updateCoverImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::updateCoverImage
 * @see app/Http/Controllers/API/User/UserController.php:245
 * @route '/api/v1/user/update/cover-image'
 */
updateCoverImage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateCoverImage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::updateCoverImage
 * @see app/Http/Controllers/API/User/UserController.php:245
 * @route '/api/v1/user/update/cover-image'
 */
    const updateCoverImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCoverImage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::updateCoverImage
 * @see app/Http/Controllers/API/User/UserController.php:245
 * @route '/api/v1/user/update/cover-image'
 */
        updateCoverImageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCoverImage.url(options),
            method: 'post',
        })
    
    updateCoverImage.form = updateCoverImageForm
/**
* @see \App\Http\Controllers\API\User\UserController::updateCurrency
 * @see app/Http/Controllers/API/User/UserController.php:276
 * @route '/api/v1/user/update/currency'
 */
export const updateCurrency = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateCurrency.url(options),
    method: 'post',
})

updateCurrency.definition = {
    methods: ["post"],
    url: '/api/v1/user/update/currency',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::updateCurrency
 * @see app/Http/Controllers/API/User/UserController.php:276
 * @route '/api/v1/user/update/currency'
 */
updateCurrency.url = (options?: RouteQueryOptions) => {
    return updateCurrency.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::updateCurrency
 * @see app/Http/Controllers/API/User/UserController.php:276
 * @route '/api/v1/user/update/currency'
 */
updateCurrency.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateCurrency.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::updateCurrency
 * @see app/Http/Controllers/API/User/UserController.php:276
 * @route '/api/v1/user/update/currency'
 */
    const updateCurrencyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCurrency.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::updateCurrency
 * @see app/Http/Controllers/API/User/UserController.php:276
 * @route '/api/v1/user/update/currency'
 */
        updateCurrencyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCurrency.url(options),
            method: 'post',
        })
    
    updateCurrency.form = updateCurrencyForm
/**
* @see \App\Http\Controllers\API\User\UserController::follow
 * @see app/Http/Controllers/API/User/UserController.php:119
 * @route '/api/v1/user/{user}/follow'
 */
export const follow = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: follow.url(args, options),
    method: 'post',
})

follow.definition = {
    methods: ["post"],
    url: '/api/v1/user/{user}/follow',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::follow
 * @see app/Http/Controllers/API/User/UserController.php:119
 * @route '/api/v1/user/{user}/follow'
 */
follow.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return follow.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::follow
 * @see app/Http/Controllers/API/User/UserController.php:119
 * @route '/api/v1/user/{user}/follow'
 */
follow.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: follow.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::follow
 * @see app/Http/Controllers/API/User/UserController.php:119
 * @route '/api/v1/user/{user}/follow'
 */
    const followForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: follow.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::follow
 * @see app/Http/Controllers/API/User/UserController.php:119
 * @route '/api/v1/user/{user}/follow'
 */
        followForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: follow.url(args, options),
            method: 'post',
        })
    
    follow.form = followForm
/**
* @see \App\Http\Controllers\API\User\UserController::unfollow
 * @see app/Http/Controllers/API/User/UserController.php:155
 * @route '/api/v1/user/{user}/unfollow'
 */
export const unfollow = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unfollow.url(args, options),
    method: 'post',
})

unfollow.definition = {
    methods: ["post"],
    url: '/api/v1/user/{user}/unfollow',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::unfollow
 * @see app/Http/Controllers/API/User/UserController.php:155
 * @route '/api/v1/user/{user}/unfollow'
 */
unfollow.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return unfollow.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::unfollow
 * @see app/Http/Controllers/API/User/UserController.php:155
 * @route '/api/v1/user/{user}/unfollow'
 */
unfollow.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unfollow.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::unfollow
 * @see app/Http/Controllers/API/User/UserController.php:155
 * @route '/api/v1/user/{user}/unfollow'
 */
    const unfollowForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unfollow.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::unfollow
 * @see app/Http/Controllers/API/User/UserController.php:155
 * @route '/api/v1/user/{user}/unfollow'
 */
        unfollowForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unfollow.url(args, options),
            method: 'post',
        })
    
    unfollow.form = unfollowForm
/**
* @see \App\Http\Controllers\API\User\UserController::toggleFollow
 * @see app/Http/Controllers/API/User/UserController.php:183
 * @route '/api/v1/user/{user}/toggle-follow'
 */
export const toggleFollow = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleFollow.url(args, options),
    method: 'post',
})

toggleFollow.definition = {
    methods: ["post"],
    url: '/api/v1/user/{user}/toggle-follow',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserController::toggleFollow
 * @see app/Http/Controllers/API/User/UserController.php:183
 * @route '/api/v1/user/{user}/toggle-follow'
 */
toggleFollow.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return toggleFollow.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::toggleFollow
 * @see app/Http/Controllers/API/User/UserController.php:183
 * @route '/api/v1/user/{user}/toggle-follow'
 */
toggleFollow.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleFollow.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::toggleFollow
 * @see app/Http/Controllers/API/User/UserController.php:183
 * @route '/api/v1/user/{user}/toggle-follow'
 */
    const toggleFollowForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleFollow.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::toggleFollow
 * @see app/Http/Controllers/API/User/UserController.php:183
 * @route '/api/v1/user/{user}/toggle-follow'
 */
        toggleFollowForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleFollow.url(args, options),
            method: 'post',
        })
    
    toggleFollow.form = toggleFollowForm
/**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
export const getFollowers = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFollowers.url(args, options),
    method: 'get',
})

getFollowers.definition = {
    methods: ["get","head"],
    url: '/api/v1/user/{user}/followers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
getFollowers.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return getFollowers.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
getFollowers.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFollowers.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
getFollowers.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getFollowers.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
    const getFollowersForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getFollowers.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
        getFollowersForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getFollowers.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\User\UserController::getFollowers
 * @see app/Http/Controllers/API/User/UserController.php:219
 * @route '/api/v1/user/{user}/followers'
 */
        getFollowersForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getFollowers.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getFollowers.form = getFollowersForm
/**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
export const getFollowing = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFollowing.url(args, options),
    method: 'get',
})

getFollowing.definition = {
    methods: ["get","head"],
    url: '/api/v1/user/{user}/following',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
getFollowing.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return getFollowing.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
getFollowing.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getFollowing.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
getFollowing.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getFollowing.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
    const getFollowingForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getFollowing.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
        getFollowingForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getFollowing.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\User\UserController::getFollowing
 * @see app/Http/Controllers/API/User/UserController.php:234
 * @route '/api/v1/user/{user}/following'
 */
        getFollowingForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getFollowing.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getFollowing.form = getFollowingForm
const UserController = { profile, update, updatePassword, updateNotifications, destroy, updateCoverImage, updateCurrency, follow, unfollow, toggleFollow, getFollowers, getFollowing }

export default UserController