import OpenWeatherController from './OpenWeatherController'
const Weather = {
    OpenWeatherController: Object.assign(OpenWeatherController, OpenWeatherController),
}

export default Weather