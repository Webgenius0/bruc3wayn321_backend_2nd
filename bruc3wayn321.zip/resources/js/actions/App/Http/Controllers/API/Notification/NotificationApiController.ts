import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
export const list = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})

list.definition = {
    methods: ["get","head"],
    url: '/api/v1/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
list.url = (options?: RouteQueryOptions) => {
    return list.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
list.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
list.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: list.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
    const listForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: list.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
        listForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::list
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:17
 * @route '/api/v1/notifications'
 */
        listForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    list.form = listForm
/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
export const unreadCounts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unreadCounts.url(options),
    method: 'get',
})

unreadCounts.definition = {
    methods: ["get","head"],
    url: '/api/v1/notifications/unread-counts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
unreadCounts.url = (options?: RouteQueryOptions) => {
    return unreadCounts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
unreadCounts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unreadCounts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
unreadCounts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: unreadCounts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
    const unreadCountsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: unreadCounts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
        unreadCountsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unreadCounts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Notification\NotificationApiController::unreadCounts
 * @see app/Http/Controllers/API/Notification/NotificationApiController.php:32
 * @route '/api/v1/notifications/unread-counts'
 */
        unreadCountsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: unreadCounts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    unreadCounts.form = unreadCountsForm
const NotificationApiController = { list, unreadCounts }

export default NotificationApiController