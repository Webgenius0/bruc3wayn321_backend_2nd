import ChatApiController from './ChatApiController'
const Message = {
    ChatApiController: Object.assign(ChatApiController, ChatApiController),
}

export default Message