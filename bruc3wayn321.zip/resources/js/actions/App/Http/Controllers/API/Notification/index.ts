import FirebaseTokenController from './FirebaseTokenController'
import NotificationApiController from './NotificationApiController'
const Notification = {
    FirebaseTokenController: Object.assign(FirebaseTokenController, FirebaseTokenController),
NotificationApiController: Object.assign(NotificationApiController, NotificationApiController),
}

export default Notification