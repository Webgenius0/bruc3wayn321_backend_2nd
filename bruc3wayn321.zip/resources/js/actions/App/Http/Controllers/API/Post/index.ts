import PostController from './PostController'
import LikeCommentApiController from './LikeCommentApiController'
const Post = {
    PostController: Object.assign(PostController, PostController),
LikeCommentApiController: Object.assign(LikeCommentApiController, LikeCommentApiController),
}

export default Post