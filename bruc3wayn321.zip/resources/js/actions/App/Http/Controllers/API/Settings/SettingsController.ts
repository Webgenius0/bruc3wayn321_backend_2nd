import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
export const systemSetting = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: systemSetting.url(options),
    method: 'get',
})

systemSetting.definition = {
    methods: ["get","head"],
    url: '/api/v1/settings/system',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
systemSetting.url = (options?: RouteQueryOptions) => {
    return systemSetting.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
systemSetting.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: systemSetting.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
systemSetting.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: systemSetting.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
    const systemSettingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: systemSetting.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
        systemSettingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: systemSetting.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::systemSetting
 * @see app/Http/Controllers/API/Settings/SettingsController.php:16
 * @route '/api/v1/settings/system'
 */
        systemSettingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: systemSetting.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    systemSetting.form = systemSettingForm
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
export const faqList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faqList.url(options),
    method: 'get',
})

faqList.definition = {
    methods: ["get","head"],
    url: '/api/v1/settings/faqs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
faqList.url = (options?: RouteQueryOptions) => {
    return faqList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
faqList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faqList.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
faqList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: faqList.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
    const faqListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: faqList.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
        faqListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faqList.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::faqList
 * @see app/Http/Controllers/API/Settings/SettingsController.php:49
 * @route '/api/v1/settings/faqs'
 */
        faqListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faqList.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    faqList.form = faqListForm
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
export const dynamicPage = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dynamicPage.url(args, options),
    method: 'get',
})

dynamicPage.definition = {
    methods: ["get","head"],
    url: '/api/v1/settings/page/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
dynamicPage.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return dynamicPage.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
dynamicPage.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dynamicPage.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
dynamicPage.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dynamicPage.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
    const dynamicPageForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dynamicPage.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
        dynamicPageForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dynamicPage.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Settings\SettingsController::dynamicPage
 * @see app/Http/Controllers/API/Settings/SettingsController.php:62
 * @route '/api/v1/settings/page/{slug}'
 */
        dynamicPageForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dynamicPage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dynamicPage.form = dynamicPageForm
const SettingsController = { systemSetting, faqList, dynamicPage }

export default SettingsController