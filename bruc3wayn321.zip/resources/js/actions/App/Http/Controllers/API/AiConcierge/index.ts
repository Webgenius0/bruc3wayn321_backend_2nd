import AiConciergeController from './AiConciergeController'
const AiConcierge = {
    AiConciergeController: Object.assign(AiConciergeController, AiConciergeController),
}

export default AiConcierge