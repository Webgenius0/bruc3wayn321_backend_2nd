import DestinationController from './DestinationController'
const Destination = {
    DestinationController: Object.assign(DestinationController, DestinationController),
}

export default Destination