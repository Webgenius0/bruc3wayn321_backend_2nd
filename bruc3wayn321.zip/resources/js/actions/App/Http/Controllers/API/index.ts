import Auth from './Auth'
import User from './User'
import Settings from './Settings'
import Currency from './Currency'
import Post from './Post'
import Weather from './Weather'
import Destination from './Destination'
const API = {
    Auth: Object.assign(Auth, Auth),
User: Object.assign(User, User),
Settings: Object.assign(Settings, Settings),
Currency: Object.assign(Currency, Currency),
Post: Object.assign(Post, Post),
Weather: Object.assign(Weather, Weather),
Destination: Object.assign(Destination, Destination),
}

export default API