import Auth from './Auth'
import Notification from './Notification'
import User from './User'
import Settings from './Settings'
import Currency from './Currency'
import Post from './Post'
import Weather from './Weather'
import Destination from './Destination'
import AiConcierge from './AiConcierge'
import Translate from './Translate'
import SubscriptionApiController from './SubscriptionApiController'
import SupportIssueController from './SupportIssueController'
import Message from './Message'
const API = {
    Auth: Object.assign(Auth, Auth),
Notification: Object.assign(Notification, Notification),
User: Object.assign(User, User),
Settings: Object.assign(Settings, Settings),
Currency: Object.assign(Currency, Currency),
Post: Object.assign(Post, Post),
Weather: Object.assign(Weather, Weather),
Destination: Object.assign(Destination, Destination),
AiConcierge: Object.assign(AiConcierge, AiConcierge),
Translate: Object.assign(Translate, Translate),
SubscriptionApiController: Object.assign(SubscriptionApiController, SubscriptionApiController),
SupportIssueController: Object.assign(SupportIssueController, SupportIssueController),
Message: Object.assign(Message, Message),
}

export default API