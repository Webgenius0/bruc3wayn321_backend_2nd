import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
export const trending = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: trending.url(options),
    method: 'get',
})

trending.definition = {
    methods: ["get","head"],
    url: '/api/v1/posts/trending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
trending.url = (options?: RouteQueryOptions) => {
    return trending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
trending.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: trending.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
trending.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: trending.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
    const trendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: trending.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
        trendingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: trending.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::trending
 * @see app/Http/Controllers/API/Post/PostController.php:104
 * @route '/api/v1/posts/trending'
 */
        trendingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: trending.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    trending.form = trendingForm
/**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
export const latest = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: latest.url(options),
    method: 'get',
})

latest.definition = {
    methods: ["get","head"],
    url: '/api/v1/posts/latest',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
latest.url = (options?: RouteQueryOptions) => {
    return latest.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
latest.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: latest.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
latest.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: latest.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
    const latestForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: latest.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
        latestForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: latest.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::latest
 * @see app/Http/Controllers/API/Post/PostController.php:81
 * @route '/api/v1/posts/latest'
 */
        latestForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: latest.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    latest.form = latestForm
/**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
export const followersPosts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: followersPosts.url(options),
    method: 'get',
})

followersPosts.definition = {
    methods: ["get","head"],
    url: '/api/v1/posts/followers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
followersPosts.url = (options?: RouteQueryOptions) => {
    return followersPosts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
followersPosts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: followersPosts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
followersPosts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: followersPosts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
    const followersPostsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: followersPosts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
        followersPostsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: followersPosts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::followersPosts
 * @see app/Http/Controllers/API/Post/PostController.php:56
 * @route '/api/v1/posts/followers'
 */
        followersPostsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: followersPosts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    followersPosts.form = followersPostsForm
/**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
export const userPosts = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userPosts.url(args, options),
    method: 'get',
})

userPosts.definition = {
    methods: ["get","head"],
    url: '/api/v1/posts/user/{username}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
userPosts.url = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { username: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    username: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        username: args.username,
                }

    return userPosts.definition.url
            .replace('{username}', parsedArgs.username.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
userPosts.get = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userPosts.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
userPosts.head = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userPosts.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
    const userPostsForm = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userPosts.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
        userPostsForm.get = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userPosts.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::userPosts
 * @see app/Http/Controllers/API/Post/PostController.php:29
 * @route '/api/v1/posts/user/{username}'
 */
        userPostsForm.head = (args: { username: string | number } | [username: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userPosts.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userPosts.form = userPostsForm
/**
* @see \App\Http\Controllers\API\Post\PostController::draft
 * @see app/Http/Controllers/API/Post/PostController.php:195
 * @route '/api/v1/posts/{post}/draft'
 */
export const draft = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: draft.url(args, options),
    method: 'post',
})

draft.definition = {
    methods: ["post"],
    url: '/api/v1/posts/{post}/draft',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::draft
 * @see app/Http/Controllers/API/Post/PostController.php:195
 * @route '/api/v1/posts/{post}/draft'
 */
draft.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return draft.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::draft
 * @see app/Http/Controllers/API/Post/PostController.php:195
 * @route '/api/v1/posts/{post}/draft'
 */
draft.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: draft.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::draft
 * @see app/Http/Controllers/API/Post/PostController.php:195
 * @route '/api/v1/posts/{post}/draft'
 */
    const draftForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: draft.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::draft
 * @see app/Http/Controllers/API/Post/PostController.php:195
 * @route '/api/v1/posts/{post}/draft'
 */
        draftForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: draft.url(args, options),
            method: 'post',
        })
    
    draft.form = draftForm
/**
* @see \App\Http\Controllers\API\Post\PostController::publish
 * @see app/Http/Controllers/API/Post/PostController.php:212
 * @route '/api/v1/posts/{post}/publish'
 */
export const publish = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/api/v1/posts/{post}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::publish
 * @see app/Http/Controllers/API/Post/PostController.php:212
 * @route '/api/v1/posts/{post}/publish'
 */
publish.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return publish.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::publish
 * @see app/Http/Controllers/API/Post/PostController.php:212
 * @route '/api/v1/posts/{post}/publish'
 */
publish.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::publish
 * @see app/Http/Controllers/API/Post/PostController.php:212
 * @route '/api/v1/posts/{post}/publish'
 */
    const publishForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::publish
 * @see app/Http/Controllers/API/Post/PostController.php:212
 * @route '/api/v1/posts/{post}/publish'
 */
        publishForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\API\Post\PostController::store
 * @see app/Http/Controllers/API/Post/PostController.php:126
 * @route '/api/v1/posts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/posts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::store
 * @see app/Http/Controllers/API/Post/PostController.php:126
 * @route '/api/v1/posts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::store
 * @see app/Http/Controllers/API/Post/PostController.php:126
 * @route '/api/v1/posts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::store
 * @see app/Http/Controllers/API/Post/PostController.php:126
 * @route '/api/v1/posts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::store
 * @see app/Http/Controllers/API/Post/PostController.php:126
 * @route '/api/v1/posts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
export const show = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/post/details/{post}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
show.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return show.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
show.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
show.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
    const showForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
        showForm.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::show
 * @see app/Http/Controllers/API/Post/PostController.php:136
 * @route '/api/v1/post/details/{post}'
 */
        showForm.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\API\Post\PostController::update
 * @see app/Http/Controllers/API/Post/PostController.php:166
 * @route '/api/v1/post/update/{post}'
 */
export const update = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/v1/post/update/{post}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::update
 * @see app/Http/Controllers/API/Post/PostController.php:166
 * @route '/api/v1/post/update/{post}'
 */
update.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return update.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::update
 * @see app/Http/Controllers/API/Post/PostController.php:166
 * @route '/api/v1/post/update/{post}'
 */
update.put = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::update
 * @see app/Http/Controllers/API/Post/PostController.php:166
 * @route '/api/v1/post/update/{post}'
 */
    const updateForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::update
 * @see app/Http/Controllers/API/Post/PostController.php:166
 * @route '/api/v1/post/update/{post}'
 */
        updateForm.put = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\API\Post\PostController::postVisibility
 * @see app/Http/Controllers/API/Post/PostController.php:229
 * @route '/api/v1/post/{post}/visibility'
 */
export const postVisibility = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: postVisibility.url(args, options),
    method: 'post',
})

postVisibility.definition = {
    methods: ["post"],
    url: '/api/v1/post/{post}/visibility',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::postVisibility
 * @see app/Http/Controllers/API/Post/PostController.php:229
 * @route '/api/v1/post/{post}/visibility'
 */
postVisibility.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { post: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    post: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        post: typeof args.post === 'object'
                ? args.post.slug
                : args.post,
                }

    return postVisibility.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::postVisibility
 * @see app/Http/Controllers/API/Post/PostController.php:229
 * @route '/api/v1/post/{post}/visibility'
 */
postVisibility.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: postVisibility.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::postVisibility
 * @see app/Http/Controllers/API/Post/PostController.php:229
 * @route '/api/v1/post/{post}/visibility'
 */
    const postVisibilityForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: postVisibility.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::postVisibility
 * @see app/Http/Controllers/API/Post/PostController.php:229
 * @route '/api/v1/post/{post}/visibility'
 */
        postVisibilityForm.post = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: postVisibility.url(args, options),
            method: 'post',
        })
    
    postVisibility.form = postVisibilityForm
/**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
export const myPosts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myPosts.url(options),
    method: 'get',
})

myPosts.definition = {
    methods: ["get","head"],
    url: '/api/v1/post/my-post',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
myPosts.url = (options?: RouteQueryOptions) => {
    return myPosts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
myPosts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myPosts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
myPosts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myPosts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
    const myPostsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myPosts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
        myPostsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myPosts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Post\PostController::myPosts
 * @see app/Http/Controllers/API/Post/PostController.php:245
 * @route '/api/v1/post/my-post'
 */
        myPostsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myPosts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myPosts.form = myPostsForm
const PostController = { trending, latest, followersPosts, userPosts, draft, publish, store, show, update, postVisibility, myPosts }

export default PostController