import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/destination/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::index
 * @see app/Http/Controllers/API/Destination/DestinationController.php:18
 * @route '/api/v1/destination/list'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/destination/details/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
    const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
        showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::show
 * @see app/Http/Controllers/API/Destination/DestinationController.php:29
 * @route '/api/v1/destination/details/{id}'
 */
        showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
export const mydestination = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mydestination.url(options),
    method: 'get',
})

mydestination.definition = {
    methods: ["get","head"],
    url: '/api/v1/my-destinations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
mydestination.url = (options?: RouteQueryOptions) => {
    return mydestination.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
mydestination.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mydestination.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
mydestination.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mydestination.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
    const mydestinationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: mydestination.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
        mydestinationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mydestination.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::mydestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:63
 * @route '/api/v1/my-destinations'
 */
        mydestinationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mydestination.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    mydestination.form = mydestinationForm
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
export const userDestination = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userDestination.url(args, options),
    method: 'get',
})

userDestination.definition = {
    methods: ["get","head"],
    url: '/api/v1/user-destinations/{user_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
userDestination.url = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user_id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user_id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user_id: args.user_id,
                }

    return userDestination.definition.url
            .replace('{user_id}', parsedArgs.user_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
userDestination.get = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userDestination.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
userDestination.head = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userDestination.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
    const userDestinationForm = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userDestination.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
        userDestinationForm.get = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userDestination.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::userDestination
 * @see app/Http/Controllers/API/Destination/DestinationController.php:71
 * @route '/api/v1/user-destinations/{user_id}'
 */
        userDestinationForm.head = (args: { user_id: string | number } | [user_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userDestination.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userDestination.form = userDestinationForm
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::store
 * @see app/Http/Controllers/API/Destination/DestinationController.php:37
 * @route '/api/v1/destinations/save'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/destinations/save',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::store
 * @see app/Http/Controllers/API/Destination/DestinationController.php:37
 * @route '/api/v1/destinations/save'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::store
 * @see app/Http/Controllers/API/Destination/DestinationController.php:37
 * @route '/api/v1/destinations/save'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::store
 * @see app/Http/Controllers/API/Destination/DestinationController.php:37
 * @route '/api/v1/destinations/save'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::store
 * @see app/Http/Controllers/API/Destination/DestinationController.php:37
 * @route '/api/v1/destinations/save'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\API\Destination\DestinationController::destroy
 * @see app/Http/Controllers/API/Destination/DestinationController.php:53
 * @route '/api/v1/destinations/save/{placeId}'
 */
export const destroy = (args: { placeId: string | number } | [placeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/destinations/save/{placeId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::destroy
 * @see app/Http/Controllers/API/Destination/DestinationController.php:53
 * @route '/api/v1/destinations/save/{placeId}'
 */
destroy.url = (args: { placeId: string | number } | [placeId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { placeId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    placeId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        placeId: args.placeId,
                }

    return destroy.definition.url
            .replace('{placeId}', parsedArgs.placeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Destination\DestinationController::destroy
 * @see app/Http/Controllers/API/Destination/DestinationController.php:53
 * @route '/api/v1/destinations/save/{placeId}'
 */
destroy.delete = (args: { placeId: string | number } | [placeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\API\Destination\DestinationController::destroy
 * @see app/Http/Controllers/API/Destination/DestinationController.php:53
 * @route '/api/v1/destinations/save/{placeId}'
 */
    const destroyForm = (args: { placeId: string | number } | [placeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Destination\DestinationController::destroy
 * @see app/Http/Controllers/API/Destination/DestinationController.php:53
 * @route '/api/v1/destinations/save/{placeId}'
 */
        destroyForm.delete = (args: { placeId: string | number } | [placeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DestinationController = { index, show, mydestination, userDestination, store, destroy }

export default DestinationController