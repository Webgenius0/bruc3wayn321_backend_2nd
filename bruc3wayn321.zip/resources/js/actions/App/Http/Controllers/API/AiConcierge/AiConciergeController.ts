import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai-concierge/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::index
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:24
 * @route '/api/v1/ai-concierge/conversations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
export const show = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai-concierge/conversations/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
show.url = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { conversation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    conversation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        conversation: typeof args.conversation === 'object'
                ? args.conversation.id
                : args.conversation,
                }

    return show.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
show.get = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
show.head = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
    const showForm = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
        showForm.get = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::show
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:37
 * @route '/api/v1/ai-concierge/conversations/{conversation}'
 */
        showForm.head = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::chat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:52
 * @route '/api/v1/ai-concierge/chat'
 */
export const chat = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chat.url(options),
    method: 'post',
})

chat.definition = {
    methods: ["post"],
    url: '/api/v1/ai-concierge/chat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::chat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:52
 * @route '/api/v1/ai-concierge/chat'
 */
chat.url = (options?: RouteQueryOptions) => {
    return chat.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::chat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:52
 * @route '/api/v1/ai-concierge/chat'
 */
chat.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chat.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::chat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:52
 * @route '/api/v1/ai-concierge/chat'
 */
    const chatForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: chat.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::chat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:52
 * @route '/api/v1/ai-concierge/chat'
 */
        chatForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: chat.url(options),
            method: 'post',
        })
    
    chat.form = chatForm
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::voiceChat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:119
 * @route '/api/v1/ai-concierge/voice-chat'
 */
export const voiceChat = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voiceChat.url(options),
    method: 'post',
})

voiceChat.definition = {
    methods: ["post"],
    url: '/api/v1/ai-concierge/voice-chat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::voiceChat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:119
 * @route '/api/v1/ai-concierge/voice-chat'
 */
voiceChat.url = (options?: RouteQueryOptions) => {
    return voiceChat.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::voiceChat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:119
 * @route '/api/v1/ai-concierge/voice-chat'
 */
voiceChat.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voiceChat.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::voiceChat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:119
 * @route '/api/v1/ai-concierge/voice-chat'
 */
    const voiceChatForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: voiceChat.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::voiceChat
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:119
 * @route '/api/v1/ai-concierge/voice-chat'
 */
        voiceChatForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: voiceChat.url(options),
            method: 'post',
        })
    
    voiceChat.form = voiceChatForm
/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::destroy
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:105
 * @route '/api/v1/ai-concierge/conversations/delete/{conversation}'
 */
export const destroy = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/ai-concierge/conversations/delete/{conversation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::destroy
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:105
 * @route '/api/v1/ai-concierge/conversations/delete/{conversation}'
 */
destroy.url = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { conversation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    conversation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        conversation: typeof args.conversation === 'object'
                ? args.conversation.id
                : args.conversation,
                }

    return destroy.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::destroy
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:105
 * @route '/api/v1/ai-concierge/conversations/delete/{conversation}'
 */
destroy.delete = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::destroy
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:105
 * @route '/api/v1/ai-concierge/conversations/delete/{conversation}'
 */
    const destroyForm = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\AiConcierge\AiConciergeController::destroy
 * @see app/Http/Controllers/API/AiConcierge/AiConciergeController.php:105
 * @route '/api/v1/ai-concierge/conversations/delete/{conversation}'
 */
        destroyForm.delete = (args: { conversation: number | { id: number } } | [conversation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AiConciergeController = { index, show, chat, voiceChat, destroy }

export default AiConciergeController