import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::updateFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:16
 * @route '/api/v1/firebase-token/add'
 */
export const updateFirebaseToken = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateFirebaseToken.url(options),
    method: 'post',
})

updateFirebaseToken.definition = {
    methods: ["post"],
    url: '/api/v1/firebase-token/add',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::updateFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:16
 * @route '/api/v1/firebase-token/add'
 */
updateFirebaseToken.url = (options?: RouteQueryOptions) => {
    return updateFirebaseToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::updateFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:16
 * @route '/api/v1/firebase-token/add'
 */
updateFirebaseToken.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateFirebaseToken.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::updateFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:16
 * @route '/api/v1/firebase-token/add'
 */
    const updateFirebaseTokenForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateFirebaseToken.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::updateFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:16
 * @route '/api/v1/firebase-token/add'
 */
        updateFirebaseTokenForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateFirebaseToken.url(options),
            method: 'post',
        })
    
    updateFirebaseToken.form = updateFirebaseTokenForm
/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::deleteFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:52
 * @route '/api/v1/firebase-token/delete'
 */
export const deleteFirebaseToken = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteFirebaseToken.url(options),
    method: 'delete',
})

deleteFirebaseToken.definition = {
    methods: ["delete"],
    url: '/api/v1/firebase-token/delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::deleteFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:52
 * @route '/api/v1/firebase-token/delete'
 */
deleteFirebaseToken.url = (options?: RouteQueryOptions) => {
    return deleteFirebaseToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::deleteFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:52
 * @route '/api/v1/firebase-token/delete'
 */
deleteFirebaseToken.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteFirebaseToken.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::deleteFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:52
 * @route '/api/v1/firebase-token/delete'
 */
    const deleteFirebaseTokenForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteFirebaseToken.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::deleteFirebaseToken
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:52
 * @route '/api/v1/firebase-token/delete'
 */
        deleteFirebaseTokenForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteFirebaseToken.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteFirebaseToken.form = deleteFirebaseTokenForm
/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
export const test = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: test.url(options),
    method: 'get',
})

test.definition = {
    methods: ["get","head"],
    url: '/api/test-push',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
test.url = (options?: RouteQueryOptions) => {
    return test.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
test.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: test.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
test.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: test.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
    const testForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: test.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
        testForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: test.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Notification\FirebaseTokenController::test
 * @see app/Http/Controllers/API/Notification/FirebaseTokenController.php:74
 * @route '/api/test-push'
 */
        testForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: test.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    test.form = testForm
const FirebaseTokenController = { updateFirebaseToken, deleteFirebaseToken, test }

export default FirebaseTokenController