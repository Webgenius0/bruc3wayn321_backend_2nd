import CurrencyController from './CurrencyController'
const Currency = {
    CurrencyController: Object.assign(CurrencyController, CurrencyController),
}

export default Currency