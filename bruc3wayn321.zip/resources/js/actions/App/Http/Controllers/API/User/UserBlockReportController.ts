import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::block
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:22
 * @route '/api/v1/user/{userId}/block'
 */
export const block = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: block.url(args, options),
    method: 'post',
})

block.definition = {
    methods: ["post"],
    url: '/api/v1/user/{userId}/block',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::block
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:22
 * @route '/api/v1/user/{userId}/block'
 */
block.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return block.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::block
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:22
 * @route '/api/v1/user/{userId}/block'
 */
block.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: block.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::block
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:22
 * @route '/api/v1/user/{userId}/block'
 */
    const blockForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: block.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::block
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:22
 * @route '/api/v1/user/{userId}/block'
 */
        blockForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: block.url(args, options),
            method: 'post',
        })
    
    block.form = blockForm
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::unblock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:50
 * @route '/api/v1/user/{userId}/unblock'
 */
export const unblock = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unblock.url(args, options),
    method: 'post',
})

unblock.definition = {
    methods: ["post"],
    url: '/api/v1/user/{userId}/unblock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::unblock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:50
 * @route '/api/v1/user/{userId}/unblock'
 */
unblock.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return unblock.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::unblock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:50
 * @route '/api/v1/user/{userId}/unblock'
 */
unblock.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unblock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::unblock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:50
 * @route '/api/v1/user/{userId}/unblock'
 */
    const unblockForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unblock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::unblock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:50
 * @route '/api/v1/user/{userId}/unblock'
 */
        unblockForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unblock.url(args, options),
            method: 'post',
        })
    
    unblock.form = unblockForm
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::toggleBlock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:72
 * @route '/api/v1/user/{userId}/toggle-block'
 */
export const toggleBlock = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlock.url(args, options),
    method: 'post',
})

toggleBlock.definition = {
    methods: ["post"],
    url: '/api/v1/user/{userId}/toggle-block',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::toggleBlock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:72
 * @route '/api/v1/user/{userId}/toggle-block'
 */
toggleBlock.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return toggleBlock.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::toggleBlock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:72
 * @route '/api/v1/user/{userId}/toggle-block'
 */
toggleBlock.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::toggleBlock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:72
 * @route '/api/v1/user/{userId}/toggle-block'
 */
    const toggleBlockForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleBlock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::toggleBlock
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:72
 * @route '/api/v1/user/{userId}/toggle-block'
 */
        toggleBlockForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleBlock.url(args, options),
            method: 'post',
        })
    
    toggleBlock.form = toggleBlockForm
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
export const blockedList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blockedList.url(options),
    method: 'get',
})

blockedList.definition = {
    methods: ["get","head"],
    url: '/api/v1/user/blocked/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
blockedList.url = (options?: RouteQueryOptions) => {
    return blockedList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
blockedList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blockedList.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
blockedList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blockedList.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
    const blockedListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: blockedList.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
        blockedListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: blockedList.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockedList
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:111
 * @route '/api/v1/user/blocked/list'
 */
        blockedListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: blockedList.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    blockedList.form = blockedListForm
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
export const blockStatus = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blockStatus.url(args, options),
    method: 'get',
})

blockStatus.definition = {
    methods: ["get","head"],
    url: '/api/v1/user/{userId}/block-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
blockStatus.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return blockStatus.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
blockStatus.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blockStatus.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
blockStatus.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blockStatus.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
    const blockStatusForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: blockStatus.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
        blockStatusForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: blockStatus.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::blockStatus
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:170
 * @route '/api/v1/user/{userId}/block-status'
 */
        blockStatusForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: blockStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    blockStatus.form = blockStatusForm
/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::report
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:132
 * @route '/api/v1/user/{userId}/report'
 */
export const report = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: report.url(args, options),
    method: 'post',
})

report.definition = {
    methods: ["post"],
    url: '/api/v1/user/{userId}/report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::report
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:132
 * @route '/api/v1/user/{userId}/report'
 */
report.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return report.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\User\UserBlockReportController::report
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:132
 * @route '/api/v1/user/{userId}/report'
 */
report.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: report.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::report
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:132
 * @route '/api/v1/user/{userId}/report'
 */
    const reportForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: report.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\User\UserBlockReportController::report
 * @see app/Http/Controllers/API/User/UserBlockReportController.php:132
 * @route '/api/v1/user/{userId}/report'
 */
        reportForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: report.url(args, options),
            method: 'post',
        })
    
    report.form = reportForm
const UserBlockReportController = { block, unblock, toggleBlock, blockedList, blockStatus, report }

export default UserBlockReportController