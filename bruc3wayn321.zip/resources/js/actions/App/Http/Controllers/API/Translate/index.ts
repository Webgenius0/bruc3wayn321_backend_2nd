import TranslateImageController from './TranslateImageController'
const Translate = {
    TranslateImageController: Object.assign(TranslateImageController, TranslateImageController),
}

export default Translate