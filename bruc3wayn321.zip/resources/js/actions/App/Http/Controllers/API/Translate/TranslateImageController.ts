import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::translate
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:14
 * @route '/api/v1/translate/image'
 */
export const translate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: translate.url(options),
    method: 'post',
})

translate.definition = {
    methods: ["post"],
    url: '/api/v1/translate/image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::translate
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:14
 * @route '/api/v1/translate/image'
 */
translate.url = (options?: RouteQueryOptions) => {
    return translate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::translate
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:14
 * @route '/api/v1/translate/image'
 */
translate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: translate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::translate
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:14
 * @route '/api/v1/translate/image'
 */
    const translateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: translate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::translate
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:14
 * @route '/api/v1/translate/image'
 */
        translateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: translate.url(options),
            method: 'post',
        })
    
    translate.form = translateForm
/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
export const languages = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: languages.url(options),
    method: 'get',
})

languages.definition = {
    methods: ["get","head"],
    url: '/api/v1/translate/languages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
languages.url = (options?: RouteQueryOptions) => {
    return languages.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
languages.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: languages.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
languages.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: languages.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
    const languagesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: languages.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
        languagesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: languages.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\Translate\TranslateImageController::languages
 * @see app/Http/Controllers/API/Translate/TranslateImageController.php:65
 * @route '/api/v1/translate/languages'
 */
        languagesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: languages.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    languages.form = languagesForm
const TranslateImageController = { translate, languages }

export default TranslateImageController