import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:111
 * @route '/api/v1/subscription'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:121
 * @route '/api/v1/subscription/sync'
 */
export const sync = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:121
 * @route '/api/v1/subscription/sync'
 */
sync.url = (options?: RouteQueryOptions) => {
    return sync.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:121
 * @route '/api/v1/subscription/sync'
 */
sync.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:121
 * @route '/api/v1/subscription/sync'
 */
    const syncForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:121
 * @route '/api/v1/subscription/sync'
 */
        syncForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:131
 * @route '/api/v1/subscription/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:131
 * @route '/api/v1/subscription/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:131
 * @route '/api/v1/subscription/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:131
 * @route '/api/v1/subscription/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:131
 * @route '/api/v1/subscription/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:18
 * @route '/api/v1/webhooks/revenuecat'
 */
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

webhook.definition = {
    methods: ["post"],
    url: '/api/v1/webhooks/revenuecat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:18
 * @route '/api/v1/webhooks/revenuecat'
 */
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:18
 * @route '/api/v1/webhooks/revenuecat'
 */
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:18
 * @route '/api/v1/webhooks/revenuecat'
 */
    const webhookForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: webhook.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:18
 * @route '/api/v1/webhooks/revenuecat'
 */
        webhookForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: webhook.url(options),
            method: 'post',
        })
    
    webhook.form = webhookForm
const SubscriptionApiController = { show, sync, cancel, webhook }

export default SubscriptionApiController