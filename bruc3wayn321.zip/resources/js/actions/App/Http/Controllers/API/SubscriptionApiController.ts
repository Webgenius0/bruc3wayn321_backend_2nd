import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::show
 * @see app/Http/Controllers/API/SubscriptionApiController.php:114
 * @route '/api/v1/subscription'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:150
 * @route '/api/v1/subscription/sync'
 */
export const sync = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:150
 * @route '/api/v1/subscription/sync'
 */
sync.url = (options?: RouteQueryOptions) => {
    return sync.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:150
 * @route '/api/v1/subscription/sync'
 */
sync.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:150
 * @route '/api/v1/subscription/sync'
 */
    const syncForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::sync
 * @see app/Http/Controllers/API/SubscriptionApiController.php:150
 * @route '/api/v1/subscription/sync'
 */
        syncForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:160
 * @route '/api/v1/subscription/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:160
 * @route '/api/v1/subscription/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:160
 * @route '/api/v1/subscription/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:160
 * @route '/api/v1/subscription/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::cancel
 * @see app/Http/Controllers/API/SubscriptionApiController.php:160
 * @route '/api/v1/subscription/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:194
 * @route '/api/v1/subscription/activate-free'
 */
export const activateFree = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateFree.url(options),
    method: 'post',
})

activateFree.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/activate-free',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:194
 * @route '/api/v1/subscription/activate-free'
 */
activateFree.url = (options?: RouteQueryOptions) => {
    return activateFree.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:194
 * @route '/api/v1/subscription/activate-free'
 */
activateFree.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateFree.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:194
 * @route '/api/v1/subscription/activate-free'
 */
    const activateFreeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activateFree.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:194
 * @route '/api/v1/subscription/activate-free'
 */
        activateFreeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activateFree.url(options),
            method: 'post',
        })
    
    activateFree.form = activateFreeForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:224
 * @route '/api/v1/subscription/activate-trial'
 */
export const activateFreeTrial = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateFreeTrial.url(options),
    method: 'post',
})

activateFreeTrial.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/activate-trial',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:224
 * @route '/api/v1/subscription/activate-trial'
 */
activateFreeTrial.url = (options?: RouteQueryOptions) => {
    return activateFreeTrial.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:224
 * @route '/api/v1/subscription/activate-trial'
 */
activateFreeTrial.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateFreeTrial.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:224
 * @route '/api/v1/subscription/activate-trial'
 */
    const activateFreeTrialForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activateFreeTrial.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::activateFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:224
 * @route '/api/v1/subscription/activate-trial'
 */
        activateFreeTrialForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activateFreeTrial.url(options),
            method: 'post',
        })
    
    activateFreeTrial.form = activateFreeTrialForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
export const checkTrial = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkTrial.url(options),
    method: 'get',
})

checkTrial.definition = {
    methods: ["get","head"],
    url: '/api/v1/subscription/trial-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
checkTrial.url = (options?: RouteQueryOptions) => {
    return checkTrial.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
checkTrial.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkTrial.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
checkTrial.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkTrial.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
    const checkTrialForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: checkTrial.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
        checkTrialForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkTrial.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::checkTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:274
 * @route '/api/v1/subscription/trial-status'
 */
        checkTrialForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkTrial.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    checkTrial.form = checkTrialForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::deactivateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:349
 * @route '/api/v1/subscription/free'
 */
export const deactivateFree = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deactivateFree.url(options),
    method: 'delete',
})

deactivateFree.definition = {
    methods: ["delete"],
    url: '/api/v1/subscription/free',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::deactivateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:349
 * @route '/api/v1/subscription/free'
 */
deactivateFree.url = (options?: RouteQueryOptions) => {
    return deactivateFree.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::deactivateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:349
 * @route '/api/v1/subscription/free'
 */
deactivateFree.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deactivateFree.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::deactivateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:349
 * @route '/api/v1/subscription/free'
 */
    const deactivateFreeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deactivateFree.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::deactivateFree
 * @see app/Http/Controllers/API/SubscriptionApiController.php:349
 * @route '/api/v1/subscription/free'
 */
        deactivateFreeForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deactivateFree.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deactivateFree.form = deactivateFreeForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::extendFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:299
 * @route '/api/v1/subscription/extend-trial'
 */
export const extendFreeTrial = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendFreeTrial.url(options),
    method: 'post',
})

extendFreeTrial.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/extend-trial',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::extendFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:299
 * @route '/api/v1/subscription/extend-trial'
 */
extendFreeTrial.url = (options?: RouteQueryOptions) => {
    return extendFreeTrial.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::extendFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:299
 * @route '/api/v1/subscription/extend-trial'
 */
extendFreeTrial.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendFreeTrial.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::extendFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:299
 * @route '/api/v1/subscription/extend-trial'
 */
    const extendFreeTrialForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extendFreeTrial.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::extendFreeTrial
 * @see app/Http/Controllers/API/SubscriptionApiController.php:299
 * @route '/api/v1/subscription/extend-trial'
 */
        extendFreeTrialForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extendFreeTrial.url(options),
            method: 'post',
        })
    
    extendFreeTrial.form = extendFreeTrialForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
export const usageStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usageStats.url(options),
    method: 'get',
})

usageStats.definition = {
    methods: ["get","head"],
    url: '/api/v1/subscription/usage-stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
usageStats.url = (options?: RouteQueryOptions) => {
    return usageStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
usageStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usageStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
usageStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usageStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
    const usageStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: usageStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
        usageStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usageStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::usageStats
 * @see app/Http/Controllers/API/SubscriptionApiController.php:375
 * @route '/api/v1/subscription/usage-stats'
 */
        usageStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usageStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    usageStats.form = usageStatsForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceUpgrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:389
 * @route '/api/v1/subscription/force-upgrade/{userId}'
 */
export const forceUpgrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

forceUpgrade.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/force-upgrade/{userId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceUpgrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:389
 * @route '/api/v1/subscription/force-upgrade/{userId}'
 */
forceUpgrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceUpgrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceUpgrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:389
 * @route '/api/v1/subscription/force-upgrade/{userId}'
 */
forceUpgrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceUpgrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceUpgrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:389
 * @route '/api/v1/subscription/force-upgrade/{userId}'
 */
    const forceUpgradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceUpgrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceUpgrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:389
 * @route '/api/v1/subscription/force-upgrade/{userId}'
 */
        forceUpgradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceUpgrade.url(args, options),
            method: 'post',
        })
    
    forceUpgrade.form = forceUpgradeForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceDowngrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:418
 * @route '/api/v1/subscription/force-downgrade/{userId}'
 */
export const forceDowngrade = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

forceDowngrade.definition = {
    methods: ["post"],
    url: '/api/v1/subscription/force-downgrade/{userId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceDowngrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:418
 * @route '/api/v1/subscription/force-downgrade/{userId}'
 */
forceDowngrade.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return forceDowngrade.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceDowngrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:418
 * @route '/api/v1/subscription/force-downgrade/{userId}'
 */
forceDowngrade.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceDowngrade.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceDowngrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:418
 * @route '/api/v1/subscription/force-downgrade/{userId}'
 */
    const forceDowngradeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDowngrade.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::forceDowngrade
 * @see app/Http/Controllers/API/SubscriptionApiController.php:418
 * @route '/api/v1/subscription/force-downgrade/{userId}'
 */
        forceDowngradeForm.post = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDowngrade.url(args, options),
            method: 'post',
        })
    
    forceDowngrade.form = forceDowngradeForm
/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:20
 * @route '/api/v1/webhooks/revenuecat'
 */
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

webhook.definition = {
    methods: ["post"],
    url: '/api/v1/webhooks/revenuecat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:20
 * @route '/api/v1/webhooks/revenuecat'
 */
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:20
 * @route '/api/v1/webhooks/revenuecat'
 */
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:20
 * @route '/api/v1/webhooks/revenuecat'
 */
    const webhookForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: webhook.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\SubscriptionApiController::webhook
 * @see app/Http/Controllers/API/SubscriptionApiController.php:20
 * @route '/api/v1/webhooks/revenuecat'
 */
        webhookForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: webhook.url(options),
            method: 'post',
        })
    
    webhook.form = webhookForm
const SubscriptionApiController = { show, sync, cancel, activateFree, activateFreeTrial, checkTrial, deactivateFree, extendFreeTrial, usageStats, forceUpgrade, forceDowngrade, webhook }

export default SubscriptionApiController