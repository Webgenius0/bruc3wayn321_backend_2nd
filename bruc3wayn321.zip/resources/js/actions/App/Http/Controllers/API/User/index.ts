import UserController from './UserController'
import UserBlockReportController from './UserBlockReportController'
const User = {
    UserController: Object.assign(UserController, UserController),
UserBlockReportController: Object.assign(UserBlockReportController, UserBlockReportController),
}

export default User