import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Weather\OpenWeatherController::liveWeather
 * @see app/Http/Controllers/API/Weather/OpenWeatherController.php:15
 * @route '/api/v1/location/weather'
 */
export const liveWeather = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: liveWeather.url(options),
    method: 'post',
})

liveWeather.definition = {
    methods: ["post"],
    url: '/api/v1/location/weather',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Weather\OpenWeatherController::liveWeather
 * @see app/Http/Controllers/API/Weather/OpenWeatherController.php:15
 * @route '/api/v1/location/weather'
 */
liveWeather.url = (options?: RouteQueryOptions) => {
    return liveWeather.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Weather\OpenWeatherController::liveWeather
 * @see app/Http/Controllers/API/Weather/OpenWeatherController.php:15
 * @route '/api/v1/location/weather'
 */
liveWeather.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: liveWeather.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Weather\OpenWeatherController::liveWeather
 * @see app/Http/Controllers/API/Weather/OpenWeatherController.php:15
 * @route '/api/v1/location/weather'
 */
    const liveWeatherForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: liveWeather.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Weather\OpenWeatherController::liveWeather
 * @see app/Http/Controllers/API/Weather/OpenWeatherController.php:15
 * @route '/api/v1/location/weather'
 */
        liveWeatherForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: liveWeather.url(options),
            method: 'post',
        })
    
    liveWeather.form = liveWeatherForm
const OpenWeatherController = { liveWeather }

export default OpenWeatherController