import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::register
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:28
 * @route '/api/v1/auth/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/v1/auth/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::register
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:28
 * @route '/api/v1/auth/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::register
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:28
 * @route '/api/v1/auth/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::register
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:28
 * @route '/api/v1/auth/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::register
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:28
 * @route '/api/v1/auth/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::registerOtpResend
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:42
 * @route '/api/v1/auth/resend/register-otp'
 */
export const registerOtpResend = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerOtpResend.url(options),
    method: 'post',
})

registerOtpResend.definition = {
    methods: ["post"],
    url: '/api/v1/auth/resend/register-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::registerOtpResend
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:42
 * @route '/api/v1/auth/resend/register-otp'
 */
registerOtpResend.url = (options?: RouteQueryOptions) => {
    return registerOtpResend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::registerOtpResend
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:42
 * @route '/api/v1/auth/resend/register-otp'
 */
registerOtpResend.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerOtpResend.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::registerOtpResend
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:42
 * @route '/api/v1/auth/resend/register-otp'
 */
    const registerOtpResendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: registerOtpResend.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::registerOtpResend
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:42
 * @route '/api/v1/auth/resend/register-otp'
 */
        registerOtpResendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: registerOtpResend.url(options),
            method: 'post',
        })
    
    registerOtpResend.form = registerOtpResendForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyRegister
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:55
 * @route '/api/v1/auth/verify/register'
 */
export const verifyRegister = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyRegister.url(options),
    method: 'post',
})

verifyRegister.definition = {
    methods: ["post"],
    url: '/api/v1/auth/verify/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyRegister
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:55
 * @route '/api/v1/auth/verify/register'
 */
verifyRegister.url = (options?: RouteQueryOptions) => {
    return verifyRegister.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyRegister
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:55
 * @route '/api/v1/auth/verify/register'
 */
verifyRegister.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyRegister.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyRegister
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:55
 * @route '/api/v1/auth/verify/register'
 */
    const verifyRegisterForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyRegister.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyRegister
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:55
 * @route '/api/v1/auth/verify/register'
 */
        verifyRegisterForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyRegister.url(options),
            method: 'post',
        })
    
    verifyRegister.form = verifyRegisterForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::login
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:80
 * @route '/api/v1/auth/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/v1/auth/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::login
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:80
 * @route '/api/v1/auth/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::login
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:80
 * @route '/api/v1/auth/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::login
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:80
 * @route '/api/v1/auth/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::login
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:80
 * @route '/api/v1/auth/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::logout
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:162
 * @route '/api/v1/auth/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/v1/auth/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::logout
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:162
 * @route '/api/v1/auth/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::logout
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:162
 * @route '/api/v1/auth/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::logout
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:162
 * @route '/api/v1/auth/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::logout
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:162
 * @route '/api/v1/auth/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::forgotPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:92
 * @route '/api/v1/auth/forgetpass'
 */
export const forgotPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forgotPassword.url(options),
    method: 'post',
})

forgotPassword.definition = {
    methods: ["post"],
    url: '/api/v1/auth/forgetpass',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::forgotPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:92
 * @route '/api/v1/auth/forgetpass'
 */
forgotPassword.url = (options?: RouteQueryOptions) => {
    return forgotPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::forgotPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:92
 * @route '/api/v1/auth/forgetpass'
 */
forgotPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forgotPassword.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::forgotPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:92
 * @route '/api/v1/auth/forgetpass'
 */
    const forgotPasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forgotPassword.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::forgotPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:92
 * @route '/api/v1/auth/forgetpass'
 */
        forgotPasswordForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forgotPassword.url(options),
            method: 'post',
        })
    
    forgotPassword.form = forgotPasswordForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyForgetPass
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:105
 * @route '/api/v1/auth/verify-email'
 */
export const verifyForgetPass = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyForgetPass.url(options),
    method: 'post',
})

verifyForgetPass.definition = {
    methods: ["post"],
    url: '/api/v1/auth/verify-email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyForgetPass
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:105
 * @route '/api/v1/auth/verify-email'
 */
verifyForgetPass.url = (options?: RouteQueryOptions) => {
    return verifyForgetPass.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyForgetPass
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:105
 * @route '/api/v1/auth/verify-email'
 */
verifyForgetPass.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyForgetPass.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyForgetPass
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:105
 * @route '/api/v1/auth/verify-email'
 */
    const verifyForgetPassForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyForgetPass.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::verifyForgetPass
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:105
 * @route '/api/v1/auth/verify-email'
 */
        verifyForgetPassForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyForgetPass.url(options),
            method: 'post',
        })
    
    verifyForgetPass.form = verifyForgetPassForm
/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::resetPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:131
 * @route '/api/v1/auth/change-password'
 */
export const resetPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/api/v1/auth/change-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::resetPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:131
 * @route '/api/v1/auth/change-password'
 */
resetPassword.url = (options?: RouteQueryOptions) => {
    return resetPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\AuthApiController::resetPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:131
 * @route '/api/v1/auth/change-password'
 */
resetPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::resetPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:131
 * @route '/api/v1/auth/change-password'
 */
    const resetPasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetPassword.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\AuthApiController::resetPassword
 * @see app/Http/Controllers/API/Auth/AuthApiController.php:131
 * @route '/api/v1/auth/change-password'
 */
        resetPasswordForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetPassword.url(options),
            method: 'post',
        })
    
    resetPassword.form = resetPasswordForm
const AuthApiController = { register, registerOtpResend, verifyRegister, login, logout, forgotPassword, verifyForgetPass, resetPassword }

export default AuthApiController