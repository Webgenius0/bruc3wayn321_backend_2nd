import AuthApiController from './AuthApiController'
const Auth = {
    AuthApiController: Object.assign(AuthApiController, AuthApiController),
}

export default Auth