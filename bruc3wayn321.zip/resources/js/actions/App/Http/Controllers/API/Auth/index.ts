import AuthApiController from './AuthApiController'
import SocialAuthController from './SocialAuthController'
const Auth = {
    AuthApiController: Object.assign(AuthApiController, AuthApiController),
SocialAuthController: Object.assign(SocialAuthController, SocialAuthController),
}

export default Auth