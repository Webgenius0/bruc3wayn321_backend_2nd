import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\API\Auth\SocialAuthController::socialLogin
 * @see app/Http/Controllers/API/Auth/SocialAuthController.php:15
 * @route '/api/v1/auth/social/login'
 */
export const socialLogin = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: socialLogin.url(options),
    method: 'post',
})

socialLogin.definition = {
    methods: ["post"],
    url: '/api/v1/auth/social/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\API\Auth\SocialAuthController::socialLogin
 * @see app/Http/Controllers/API/Auth/SocialAuthController.php:15
 * @route '/api/v1/auth/social/login'
 */
socialLogin.url = (options?: RouteQueryOptions) => {
    return socialLogin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\API\Auth\SocialAuthController::socialLogin
 * @see app/Http/Controllers/API/Auth/SocialAuthController.php:15
 * @route '/api/v1/auth/social/login'
 */
socialLogin.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: socialLogin.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\API\Auth\SocialAuthController::socialLogin
 * @see app/Http/Controllers/API/Auth/SocialAuthController.php:15
 * @route '/api/v1/auth/social/login'
 */
    const socialLoginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: socialLogin.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\API\Auth\SocialAuthController::socialLogin
 * @see app/Http/Controllers/API/Auth/SocialAuthController.php:15
 * @route '/api/v1/auth/social/login'
 */
        socialLoginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: socialLogin.url(options),
            method: 'post',
        })
    
    socialLogin.form = socialLoginForm
const SocialAuthController = { socialLogin }

export default SocialAuthController