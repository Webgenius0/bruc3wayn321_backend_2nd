import { createInertiaApp } from '@inertiajs/react';
import { TooltipProvider } from '@/components/ui/tooltip';
import { initializeTheme } from '@/hooks/use-appearance';
import AppLayout from '@/layouts/app-layout';
import AuthLayout from '@/layouts/auth-layout';
import SettingsLayout from '@/layouts/settings/layout';
import MainLayout from './layouts/main-layout';
import 'react-quill-new/dist/quill.snow.css';

const appName = import.meta.env.VITE_APP_NAME || 'bruc3wayn321';

createInertiaApp({
    // title: (title) => (title ? `${title} - ${appName}` : appName),
    layout: (name) => {
        switch (true) {
            case name === 'welcome':
                return null;
            case name.startsWith('frontend/'):
                return null;
            case name.startsWith('auth/'):
                return AuthLayout;
            // case name.startsWith('settings/'):
            //     return [AppLayout, SettingsLayout];
            default:
                return MainLayout;
        }
    },
    strictMode: true,
    withApp(app) {
        return (
            <TooltipProvider delayDuration={0}>
                {app}
            </TooltipProvider>
        );
    },
    progress: {
        color: '#4B5563',
    },
});

// This will set light / dark mode on load...
initializeTheme();
