<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            "first_name"    => ['required', 'string', 'max:255'],
            "last_name"     => ['required', 'string', 'max:255'],
            'email'         => ['required', 'email'],
            'password'      => ['required', 'confirmed', 'min:8'],
            'phone'         => ['required', 'string', 'max:20'],
            'avatar'        => ['nullable'],
            'date_of_birth' => ['required', 'date', 'before:today'],
        ];
    }
}
